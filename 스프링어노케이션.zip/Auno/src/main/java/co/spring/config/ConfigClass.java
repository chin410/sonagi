package co.spring.config;

import javax.management.ConstructorParameters;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import co.spring.beans.Bean1;
import co.spring.beans.Bean2;
import co.spring.beans.Bean3;
import co.spring.beans.Bean4;
import co.spring.beans.Data1;
import co.spring.beans.Data2;
import co.spring.beans.Data3;



@Configuration //선언
//1개이상의 @Bean을 제공하는 클래스일 떄 반드시 @Configuration붙임
public class ConfigClass {
	/*@Bean(initMethod = "init",destroyMethod = "destory" )
	@Lazy
	public Bean1 sp1() {
		Bean1 b1 = new Bean1();
		return b1;
	}
	
	@Bean
	@Lazy //lazy-init
	public Bean2 sp2() {
		Bean2 b2 = new Bean2();
		return b2;
	}
	
	@Bean
	@Lazy
	@Scope("prototype") //중복생성
	public Bean3 sp3() {
		Bean3 bean3 = new Bean3();
		return bean3;
	}
	
	@Bean
	@Primary//우선순위
	public Bean4 sp4() {
		Bean4 bean4 = new Bean4();
		return bean4;
	}
	
	@Bean(name="sp6")//네임값 지정
	public Bean1 sp5() {
		Bean1 b5 = new Bean1();
		return b5;
	}*/
	
	@Bean(name = ("b1"))
	public Bean1 bean1() {
		Bean1 b1=new Bean1();
		b1.setD1(100);
		b1.setD2("인영");
		b1.setD3(new Data1());
		return b1;
	}
	
	@Bean(name = "d1")
	public Data2 data21() {
		return new Data2();
	}
	
	@Bean(name = "d2")
	public Data2 data22() {
		return new Data2();
	}
	
	@Bean(autowire = Autowire.BY_NAME,name = "b2") //BY_NAME=객체 여러개 생성
	
	public Bean2 b2() {
		return new Bean2();
	}
	
	@Bean
	public Data3 data3() {
		return new Data3();
	}
	
	@Bean(autowire = Autowire.BY_TYPE, name = "b3")//BY_TYPE=싱글톤
	public Bean3 bean3() {
		return new Bean3();
	}

}
