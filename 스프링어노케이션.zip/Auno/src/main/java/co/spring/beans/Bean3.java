package co.spring.beans;

public class Bean3 {
	private Data3 d1;
	private Data3 d2;
	
	
	public Data3 getD1() {
		return d1;
	}
	public void setD1(Data3 d1) {
		this.d1 = d1;
	}
	public Data3 getD2() {
		return d2;
	}
	public void setD2(Data3 d2) {
		this.d2 = d2;
	}
	
}
