package co.spring.beans;

public class Bean1 {

	private int d1;
	private String d2;
	private Data1 d3;

	public Bean1() {
	}

	public Bean1(int d1, String d2, Data1 d3) {
		this.d1 = d1;
		this.d2 = d2;
		this.d3 = d3;
	}

	public int getD1() {
		return d1;
	}

	public void setD1(int d1) {
		this.d1 = d1;
	}

	public String getD2() {
		return d2;
	}

	public void setD2(String d2) {
		this.d2 = d2;
	}

	public Data1 getD3() {
		return d3;
	}

	public void setD3(Data1 d3) {
		this.d3 = d3;
	}
	
	public void sh() {
		System.out.println(d1+","+d2+","+d3);
	}
	
}
