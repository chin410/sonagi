package co.spring.beans;

public class Data1 {
	private int d1;
	
	public Data1() {
		System.out.println("데이타1");
	}

}
