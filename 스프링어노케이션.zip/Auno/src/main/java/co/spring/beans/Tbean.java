package co.spring.beans;

public class Tbean {
	private int d1;
	private String d2;
	private Data1 d3;
	private Data1 d4;
	
	public Tbean() {
		System.out.println("생성자");
	}

	public int getD1() {
		return d1;
	}

	public void setD1(int d1) {
		this.d1 = d1;
	}

	public String getD2() {
		return d2;
	}

	public void setD2(String d2) {
		this.d2 = d2;
	}

	public Data1 getD3() {
		return d3;
	}

	public void setD3(Data1 d3) {
		this.d3 = d3;
	}

	public Data1 getD4() {
		return d4;
	}

	public void setD4(Data1 d4) {
		this.d4 = d4;
	}
	
	public void sh() {
		System.out.println(d1+","+d2+","+d3+","+d4);
	}
	

}
