package co.spring.beans;

public class Data3 {
	
	public Data3() {
		System.out.println("데이타3");
	}

}
