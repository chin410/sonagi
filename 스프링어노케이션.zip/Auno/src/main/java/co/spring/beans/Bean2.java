package co.spring.beans;

public class Bean2 {
	private Data2 d1;
	private Data2 d2;
	
	public Bean2() {
		System.out.println("Bean2 생성자");
	}
	public Data2 getD1() {
		return d1;
	}
	public void setD1(Data2 d1) {
		this.d1 = d1;
	}
	public Data2 getD2() {
		return d2;
	}
	public void setD2(Data2 d2) {
		this.d2 = d2;
	}
	
}
