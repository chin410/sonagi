package co.spring.beans;

public class Bean4 {
	
	public Bean4() {
		System.out.println("Bean4 생성자");
	}
}
