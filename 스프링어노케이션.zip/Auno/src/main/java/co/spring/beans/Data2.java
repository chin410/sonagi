package co.spring.beans;

public class Data2 {
	
	public Data2() {
		System.out.println("데이타2");
	}

}
