package co.spring.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import co.spring.beans.Bean1;
import co.spring.beans.Bean2;
import co.spring.beans.Bean3;
import co.spring.beans.Bean4;
import co.spring.beans.Tbean;
import co.spring.config.ConfigClass;

public class Main {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("co/spring/config/aa.xml");
		Tbean tb = ctx.getBean("b1",Tbean.class);
		
		/*Resource re = new ClassPathResource("co/spring/config/aa.xml");
		BeanFactory be = new XmlBeanFactory(re);*/
		
		tb.sh();
		
		
	}

}
