import java.util.*;
public class D01_08 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	/*//1
	System.out.printf("%.2f",5.0/3.0);
	
	//2
	System.out.println("Ű �Է�");
	int tall=sc.nextInt();
	if(tall<160) {
		System.out.println("small");
	}else if(tall<170) {
		System.out.println("medium");
	}else if(tall<180) {
		System.out.println("large");
	}
	
	//3
	int n1=50,n2=100;
	
	int n3=n1>n2 ? n1:n2;
	System.out.println(n3);
	
	//4
	System.out.println("����, Ű �Է�");
	int age=sc.nextInt();
	int ki=sc.nextInt();
	String size;
	
	if(age>20) {
		if(ki>=175) {
			size="L";
			System.out.println(size);
		}else if(ki>=165) {
			size="M";
			System.out.println(size);
		}else if(ki<165) {
			size="S";
			System.out.println(size);
		}
	}if(age<20) {
		if(ki>=170) {
			size="L";
			System.out.println(size);
		}else if(ki>=160) {
			size="M";
			System.out.println(size);
		}else if(ki<160) {
			size="S";
			System.out.println(size);
		}
	}
	
	//5
	for(int i=1; i<=50; i++) {
		System.out.println(i);
	}
	
	//5-1
	for(int i=1; i<=50; i++) {
		if(i%6==0) {
		System.out.println(i);
		}
	}
	//5-2
	int sum=0;
	for(int i=1; i<=50; i++) {
		sum+=i;
	}
	System.out.println(sum);
	
	//5-3
	int r=(int)(Math.random()*50)+1;
	System.out.println(r);
	
	//6
	int a=10,b=20;
	String c=sc.next();
	
	switch(c) {
	case "+":
		System.out.println(a+b);
		break;
	case "-":
		System.out.println(a-b);
		break;
	case "*":
		System.out.println(a*b);
		break;
	case "/":
		System.out.println(a/b);
		break;
					*/
	
	/*for(int i=0;i<9;i++){
		if(i<5) {
		for(int j=0; j<4-i; j++) {
				System.out.print(" ");
		}
		for(int j=0; j<i+1; j++) {
			System.out.print("*");
		}
		}else {
			for(int j=0; j<i-4; j++) {
				System.out.print(" ");
		}
		for(int j=0; j<9-i; j++) {
			System.out.print("*");
		}
		}
		System.out.println();
	}*/
	
	/*for(int i=0; i<5; i++) {
		for(int j=0; j<4-i; j++) {
			System.out.print(" ");
			}
		int n=1;
		for(int j=0; j<i+(i+1); j++) {
			System.out.print(n);
			n+=1;
		}
		System.out.println();	
	}*/
	
	/*System.out.println("������");
	int n=sc.nextInt();
	
	switch(n) {
	case 2 :
		for(int i=1; i<=9; i++) {
			System.out.printf("%d X %d = %d\n",n,i,n*i);
		}
		break;
	case 3 :
		for(int i=1; i<=9; i++) {
			System.out.printf("%d X %d = %\n",n,i,n*i);
		}
		break;
	case 4 :
		for(int i=1; i<=9; i++) {
			System.out.printf("%d X %d = %d\n",n,i,n*i);
		}
		break;
	default:
		System.out.println("�߸��Է�");
	}*/
	
	int n=1;
	for(int i=0; i<5; i++) {
		for(int j=0; j<4-i; j++) {
			System.out.print(" ");
		}
		for(int j=0; j<i+1; j++) {
		System.out.print("*");
		}	
		System.out.println();
	}
	
	}
}
