import java.util.*;
public class ddd {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*for(int i=0; i<9;i++) {
			if(i<5) {
			for(int j=0; j<4-i; j++) {
				System.out.print(" ");
			}
			for(int j=0; j<i*2+1; j++) {            
				System.out.printf("*");               
			}                                           
			}else {
				for(int j=0; j<i-4; j++) {
					System.out.print(" ");}
				
				for(int j=0; j<17-i*2; j++) {                 
					System.out.printf("*"); }   
					
				}                                     
			System.out.println();
		}*/
		
		
		/*System.out.println("�� �Է�");
	int n= sc.nextInt();
		
		for(int i=0; i<n;i++) {
			if(i<n/2+1) {
			for(int j=0; j<n-(5+i); j++) {
				System.out.print(" ");
			}
			for(int j=0; j<i*2+1; j++) {            
				System.out.printf("*");               
			}                                           
			}else {
				for(int j=0; j<i-4; j++) { 
					System.out.print(" ");}
				
				for(int j=0; j<(n*2-1)-i*2; j++) {                 
					System.out.printf("*"); }   
					
				}                                     
			System.out.println();
		}*/
		
		
		
		
		
		/*for(int i=0; i<5; i++) {
			int n=1;
		    for(int j=0; j<4-i; j++) {
		    	System.out.print(" ");
		    }
			for(int j=0; j<i*2+1; j++) {
				System.out.print(n);
				n++;
			}
			System.out.println();
		}*/
		
		
		
		

	}

}
