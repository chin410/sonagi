import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Day01_18_4 {

	public static void main(String[] args) throws IOException {
		
		DataOutputStream out=null;
		
		try {
			int a=5;
			double b=1.5;
			boolean c=true;
			FileOutputStream fi= new FileOutputStream("h.txt");  //���� ����,����
			out=new DataOutputStream(fi);
			
			out.writeInt(a);
			out.writeDouble(b);
			out.writeBoolean(c);
		}catch(Exception e) {}
		out.close();
		
		DataInputStream in =null;
		try {
			FileInputStream fi = new FileInputStream("h.txt"); //���� �о�ͼ� ���
			in=new DataInputStream(fi);
			
			int a=in.readInt();
			double b=in.readDouble();
			boolean c=in.readBoolean();
			
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
		}catch(Exception e){}
		in.close();

	}

}
