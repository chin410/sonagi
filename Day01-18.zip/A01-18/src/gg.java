import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class gg {

	public static void main(String[] args) throws IOException {
		FileWriter fs = new FileWriter("gugu.txt");
		BufferedWriter out = new BufferedWriter(fs);
		
		for(int i=2; i<=9; i++) {
			for(int j=1; j<=9; j++) {
				out.write(i+" X "+j+"="+i*j+" ");
			}
		out.write("\n");	
		}
		out.close();
		
		FileReader fr = new FileReader("gugu.txt");  //���ΰ�
		BufferedReader in = new BufferedReader(fr);
		
       String str;
		
		while(true){
		str=in.readLine();
		if(str==null) {
			break;
		}
		System.out.println(str);
		}
		
		in.close();
	
		
		

	}

}
