import java.io.IOException;
import java.util.*;
public class a {
	
	static void func(int a) {
		int e=a/5;
		int f=a%5;
		System.out.printf("��:%d,������:%d\n",e,f);
	}
	
	static void pr(int a [],int b) {
		int n;
		for(int i=0; i<a.length; i++) {
			n=a[i]/b;
			for(int j=0; j<n; j++) {
				System.out.print("#");
			}
			System.out.println();
		}
	}
	static String show(String a,int b) {
		String c="";  //���ڿ� ����
		for(int i=0; i<b; i++) {
			c=c.concat(a);
		}
		return c;
		
	}
	
	
		

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*int c;
		int d;
		
		System.out.println("���� �� �Է�");
		int f=sc.nextInt();

		func(f);
		
		while(true) {
			try {
				System.out.println("�� �� �Է� �Ǽ�x");
				int a=sc.nextInt();
				int b=sc.nextInt();
				System.out.println(a+b);
				
			}catch(InputMismatchException e) {
				System.out.println("�Ǽ��� �ȵȴ� �ٽ� �Է� �Ͻÿ�.");
				sc.nextLine();//���Է�
				continue;
			}*/
		
		//1
		int score[]=new int[] {58, 60, 86, 90, 84};
		pr(score,5); 
		
		//2
		 System.out.println(show("$" , 10));
		 
		 //3
		 String str = "���δ� �������, ��ճ׿�";
		 String st[]=str.split(",");
		 System.out.println(st[0]);
		 System.out.println(st[1]);
		 System.out.println(str.substring(6,7));
		 System.out.println( str.substring(0, 3));
		 
		 	 
		 
		 
			
			
		
		
	}

}
