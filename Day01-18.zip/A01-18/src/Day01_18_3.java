import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Day01_18_3 {

	public static void main(String[] args) throws IOException {
		/*InputStreamReader in = new InputStreamReader(System.in); //������ ���� �Ἥ �Է�
		FileWriter out = null; //���
		
		int r;
		try {
			out=new FileWriter("f.txt"); //f.txt�� ��ǲ��Ʈ���������� �� ���ڸ� ����
			while((r=in.read())!=-1) {
				out.write(r);
			}
			in.close();
			out.close();
		}catch(Exception e) {
			System.out.println("����� ����");
		}*/
		
		
		
		
		//ByteArrayInputStream ByteArrayOutputStream
		
		/*byte []in= {1,2,3,4,5};
		byte [] out=null;
		
		ByteArrayInputStream input=null;
		ByteArrayOutputStream output=null;
		
		output=new ByteArrayOutputStream();
		input=new ByteArrayInputStream(in);
		
v
		out=output.toByteArray();
		System.out.println(Arrays.toString(in));
		System.out.println(Arrays.toString(out));*/
		
		/*ByteArrayInputStream in= null;
		FileOutputStream out = null;
		
		try {
			byte[] b = new byte[] {1,2,3};
			in=new ByteArrayInputStream(b);
			out=new FileOutputStream("g.dat");
			
			int r=-1;
			while((r=in.read())!=-1) {
				out.write(r);            //�迭�� ������
			}
		}catch(Exception e) {}
		out.close();
		in.close();*/
		
		
		//ByteArrayInputStream , FileOutputStream
		
		  ByteArrayInputStream in=null;

		  FileOutputStream out=null;

		  //OutputStream out=new FileOutputStream("g.dat");

		  // �θ� Ŭ����                               �ڽ�Ŭ����

		  try {

		   byte[] b=new byte[] {1,2,3};

		   in=new ByteArrayInputStream(b);

		   out=new FileOutputStream("g.dat");

		   

		   int r=-1;

		   while((r=in.read())!=-1) {

		    out.write(r);

		   }

		   

		  }catch(Exception e) {}

		  out.close();

		  in.close();
		
		
		
		
		

	}

}
