class Profile{
	int age;
	String name;
	
	void show(){
		System.out.println(age+" "+name);
	}
}

class Circle{
	private int r;
	private String name;
	
	double area() {
		return 3*14*r*r;
	}
	void show() {
		System.out.println(name);
	}
}

public class class_running {

	public static void main(String[] args) {
		Profile h1 =new Profile();
		h1.age=24;
		h1.name="���ο�";
		
		h1.show();
	}

}
