import java.util.*;
public class d01_08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		/*System.out.println("ù��° �� �Է�");
		int i=sc.nextInt();
		
		System.out.println("������ �Է�");
		String a=sc.next();
		
		System.out.println("�ι�° �� �Է�");
		int j=sc.nextInt();
		
		//���ڿ� �񱳴� equals
		if(a.equals("+")) {
			System.out.println(i+j);
		}else if(a.equals("-")) {
			System.out.println(i-j);
		}else if(a.equals("*")) {
			System.out.println(i*j);
		}else if(a.equals("/")) {
			System.out.println(i/j);
		}*/
		
		/*int score;
		System.out.println("�����Է�");
		score=sc.nextInt();
		String grade;
		if(score>=90) {
			grade="A";
			System.out.println(grade);
		}if(score>=80&&score<90) {
			grade="B";
			System.out.println(grade);
		}if(score>=70&&score<80) {
			grade="C";
			System.out.println(grade);
		}if(score<70) {
			grade="F";
			System.out.println(grade);
		}*/
		
		/*double tall;
		double weight;
		System.out.println("Ű,������ �Է�");
		tall=sc.nextDouble();
		weight=sc.nextDouble();
		
		if(tall>=187.5&&weight>=80.0) {
			System.out.println("ok");
		}else {
			System.out.println("cancel");
		}*/
		
		/*int a=20,b=10;
		if(a<10) {
			if(b>=0) {
				b=1;
			}else {
				b=-1;
			}
			System.out.println(a+" "+b);
		}*/
		
		/*int age=25, kg=60;
		char size;
		
		if(age<20) {
			if(kg<50) {
				size='S';
				
			}if(kg<60) {
				size='M';
				
			}else
				size='L';
			}
		else {
			if(kg<60) 
			size='S';
			
			else if(kg<70) 
			size='M';
			
		    else
			size='L';
				
		}
		System.out.println(size);
		*/
		
		/*char grade;
		int a=300;
		int b=a/3;
		
		if(b>=90) {
			grade='A';
			System.out.println(grade);
		}if(b>=80&&b<90) {
			grade='B';
			System.out.println(grade);
		}
		if(b>=70&&b<80) {
			grade='C';
			System.out.println(grade);
		}if(b<70) {
			grade='F';
			System.out.println(grade);
		}*/
		
		/*int score;
		int grade;
		System.out.println("����,�г� �Է�");
		score=sc.nextInt();
		grade=sc.nextInt();
		
		if(score>=70) {
			if(grade!=4) {
				System.out.println("�հ�");
			}
			else if(score>=80) {
				System.out.println("�հ�");
			}else {
				System.out.println("���հ�");
			}
		}else {
			System.out.println("���հ�");
		}*/
		
		//�������� ������ ������ �� �̸� �տ��� ���� �����̸� �ڿ��� ����
		//���ǽ� ? true : false
		/*int score=85;
		char grade=(score>90)?'A':'B';
		System.out.println(grade);*/
		
		
		//swich case��
		/*System.out.println("���� ��������?");
		
		String day=sc.next();
		
		switch(day) {
		case"�����":
			System.out.println("��");
			break;
		case"�ݿ���":
			System.out.println("��");
			break;
		default:
			System.out.println("��,�� �ƴ�");
	
		}*/
		
		/*String a;
		System.out.println("�����Է�");
		a=sc.next();
		switch(a) {
		case "m":{
			System.out.println("movie");
			break;}
		case "s":{
			System.out.println("sing");
			break;}
		case "b":{
			System.out.println("book");
			break;}
		default:{
			System.out.println("etc");
			}
		}*/
		
		//char���� next()����
		//char ch=sc.next().charAt(0);
		
		/*System.out.println("�����Է�");
		char grade=sc.next().charAt(0);
		
		switch(grade) {
		
		case 'A':
		case 'B':
			System.out.println("Excellent");
			break;
		case 'C':
		case 'D':
			System.out.println("Good");
			break;
		default :
			System.out.println("Bad");
		}*/
		
		//�ݺ���
		
		/*0.0 *10 <= Math.random() *10  < 1.0 *10
				
				0.0 <= (int)Math.random() *10 < 10.0
				
				(int)0.0 <= (int)Math.random() *10 < (int)10.0
				
			      0 +1 <= (int)Math.random() *10 +1 < 10 +1
			      
			      1 <= (int)Math.random() *10 +1 < 11*/
		
        /*int n=(int)(Math.random()*100)+1;
		
		if(n%5==0&&n%10==0) {
			System.out.println("5�� ����̸鼭 10�ǹ��");
		}else if(n%5==0) {
			System.out.println("5�ǹ��");
		}
		else if(n%10==0){
			System.out.println("10�� ���");
		}else {
			System.out.println("�ƴ�");
		}*/
		
		/*int score=(int)(Math.random()*20)+81;
		System.out.println(score);
		
		String grade;
		
		if(score>=90) {
			if(score>=95) {
				grade="A+";
				}
			else {
				grade="A";
			}
			System.out.println(grade);
		}else {
			if(score>=85) {
				grade="B+";
			}else {
				grade="B";
			}
			System.out.println(grade);
		}*/
		
		//184P 12��
		/*System.out.println("ù��° ���� �Է��ϼ��� :");
		int i=sc.nextInt();
		System.out.println("������ �Է� :");
		String k=sc.next();
		System.out.println("�ι�° ���� �Է��ϼ��� :");
		int j=sc.nextInt();
		
		if(k.equals("+")) {
			System.out.println(i+" "+k+" "+j+" = "+(i+j)+" �Դϴ�.");
		}
		else if(k.equals("-")) {
		System.out.println(i+" "+k+" "+j+" = "+(i-j)+" �Դϴ�.");
		}
		else if(k.equals("*")) {
		System.out.println(i+" "+k+" "+j+" = "+(i/j)+" �Դϴ�.");
		}
		else if(k.equals("/")) {
		System.out.println(i+" "+k+" "+j+" = "+(i*j)+" �Դϴ�.");
		}
		else if(k.equals("%")) {
		System.out.println(i+" "+k+" "+j+" = "+(i%j)+" �Դϴ�.");
		}else {
			System.out.println("�����ڸ� �߸�  �Է���");
		}*/
		
		//185P 13��
		/*System.out.println("������ ���ٷ� �Է�");
		int i=sc.nextInt();
		char a=sc.next().charAt(0);
		int j=sc.nextInt();
		
		switch(a) {
		case '+':
			System.out.println(i+" + "+j+" = "+(i+j)+" �Դϴ�.");
			break;
		case '-':
			System.out.println(i+" - "+j+" = "+(i-j)+" �Դϴ�.");
			break;
		case '*':
			System.out.println(i+" * "+j+" = "+(i*j)+" �Դϴ�.");
			break;
		case '/':
			System.out.println(i+" / "+j+" = "+(i/j)+" �Դϴ�.");
			break;
		case '%':
			System.out.println(i+" % "+j+" = "+(i%j)+" �Դϴ�.");
			break;
		default :
			System.out.println("������ �߸� �Է� ��");
		}*/
		

		
		
		
}		
}
