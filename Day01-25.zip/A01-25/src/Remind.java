class Book{
	String a;
	String b="�۰� �̻�";
	Book(String a,String b){
		this.a=a;
		this.b=b;
	}
	Book(String a){
		this.a=a;	
	}
	Book(){
		System.out.println("������ ȣ��!!");
	}
	void show() {
		System.out.println(a+" "+b);
	}
}


class Friend{

    private String name;

    private String phone;

Friend(String name, String phone){

    this.name=name;  this.phone=phone; }

String get(){

  return name + " ��ȣ "+phone;}
}

class ITFriend extends Friend{
	String grade;
	ITFriend(String a,String b,String c){
		super(a,b);
		grade=c;
	}
	void show() {
		System.out.println(grade+" "+super.get());
	}
}
public class Remind {

	public static void main(String[] args) {
	    ITFriend it=new ITFriend("ȫ�浿", "010-111-1111", "��ǻ��");

	    it.show();      
		 

	}

}
