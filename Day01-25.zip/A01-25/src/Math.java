import java.util.StringTokenizer;

class Num{
	int a;
	Num(int a){
		this.a=a;
	}
	int get() {
		return a;
}
	
}
class Com{
	String a,b;
	Com(String a,String b){
		this.a=a;
		this.b=b;
	}
}
public class Math {

	public static void main(String[] args) {
		String str="id=123#name=sibal#addr=seoul";
		
		StringTokenizer s = new StringTokenizer(str, "#"); //���ø�
		System.out.println(s);
		
		int n=s.countTokens();
		System.out.println(n);
		
		while(s.hasMoreTokens()) {
			String a=s.nextToken();
			System.out.println(a);
		}
		
		Num ary[]=new Num[] {new Num(1),new Num(2),new Num(3)};
		
		for(Num a:ary) {
			System.out.println(a.get());
		}
		
		Com c[]=new Com[3];
		
		for(int i=0; i<3; i++) {
			c[i]=new Com("����","�ƾ�");
			System.out.println(c[i].a+" "+c[i].b);
		}
		
		
	}

}
