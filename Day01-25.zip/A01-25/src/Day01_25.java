class Point{
	int a,b;
	Point(int a,int b){
		this.a=a;
		this.b=b;
	}
	public String toString() { //���ڷ� ��ȭ��Ű�� �Լ�
		return a+","+b;
	}
}

class Tv{
	
private int size;

Tv(int size){
  this.size=size; }

protected int getsize(){
   return size; }

}

class Tv1 extends Tv{
	String name;
	
	Tv1(int size,String a) {
		super(size);
		name=a;
	}
	void show() {
		int size=getsize();
		System.out.println(name+" "+size+"��ġ Tv");
	}
	
}

class Shape{
	int a,b;
	String c;
	Shape(){
		a=1;
		b=3;
	}
	
	Shape(int a,int b){
		this.a=a;
		this.b=b;
	}
	void pr(String c) {
		this.c=c;
	}
	void show() {
		for(int i=0; i<a; i++) {
			for(int j=0; j<b; j++) {
				System.out.print(c);
			}
			System.out.println();
		}
	}
}


class XY{

 private int x,y;

 XY(int x, int y){

    this.x=x; this.y=y; }

 int getx(){

     return x; }

 int gety(){

     return y;}

 protected void move(int x, int y){

   this.x=x;

   this.y=y;

    }
 
}

class XYZ extends XY{
	int x,y;
	String Color;
	XYZ(int a,int b,String c){//�ȿ��ִ� �ŰԺ��� ������ super()�� ä��
		super(a,b);
		x=a;
		y=b;
		Color=c;
		
	}
	void setxy(int a, int b) {
	move(a,b);
	   x=getx();
	   y=gety();
		
	}
	void setcolor(String c) {
	Color=c;
		
	}
	void show() {
	System.out.println(x+","+y+"�� "+Color+"��!");
		
	}
	
	
}

interface Re{
	default void show() {
	System.out.println("�簢��!!");
	}
	abstract int area();
}
class Rec implements Re{
	int x,y;
	Rec(int a,int b){
		x=a;
		y=b;
	}
	
	public int area() {
		return x*y;
	}
}
public class Day01_25 {

	public static void main(String[] args) {
	   /*Point p = new Point(3,4);

		System.out.println(p);
		
		String str= "841111-1234560";
		String a=str.substring(7,8);
		
		switch(a) {
		case "1":
			System.out.println("����");
			break;
		case "2":
			System.out.println("����");
			break;
		}
		
		Tv1 t=new Tv1(20, "�Ｚ"); 

		 t.show();  
		 
		 Shape s = new Shape();

		 Shape s1 = new Shape(2,5);

		 s.pr("@"); 
		 s1.pr("#");

		 s.show();  

		 s1.show(); */
		
		/*XYZ xyz= new XYZ(10,10, "red");
		xyz.show();

		xyz.setxy(20,30);

		xyz.setcolor("blue"); 

		xyz.show();*/
		
		  Re r=new Rec(10,20);

		  r.show();         //"�簢��!!" ���

		  System.out.println("���� "+r.area());
		
		
	}

}
