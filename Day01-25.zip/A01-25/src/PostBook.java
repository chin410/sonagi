import java.util.*;
class PhoneNum{
	String name;
	String phone;
	
	PhoneNum(String n,String p){
		name=n;
		phone=p;
	}
	void show() {
		System.out.println("�̸� "+name);
		System.out.println("��ȣ "+phone);
	}
}
class School extends PhoneNum{
	String major;
	School(String n,String p,String m){
		super(n,p);
		major=m;
	}
	void show() {
		super.show(); //�θ� �Լ� ȣ��
		System.out.println("���� "+major);
	}
}
class Woker extends PhoneNum{
	String grade;
	Woker(String n, String p,String g) {
		super(n,p);
		grade=g;		
	}
	
	void show() {
		super.show();
		System.out.println("���� "+grade);
	}
}
///////////////////////////////////////////////////
class Arr{
	PhoneNum[] ary;//�迭����
	int n;
	
	Arr(int n){ //�����ھȿ���
		ary= new PhoneNum[n];//�迭����
		n=0; 
       }
	
	void add(PhoneNum p) {
		ary[n++]=p;
	}
	void friend(char ch) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�̸�:");
		String name=sc.next();
		System.out.println("��ȣ:");
		String num=sc.next();
		
		switch(ch) {
		case 'A':
			System.out.println("����:");
			String major=sc.next();
			//PhoneNum p = new School(name,num,major);
			add(new School(name,num,major));
			break;
		case 'B':
			System.out.println("����:");
			String grade=sc.next();
			//PhoneNum p = new Woker(name,num,grade);
			add(new Woker(name,num,grade));
			break;
		}
	}
	void all() {
		for(int i=0; i<ary.length; i++) {
			ary[i].show();
		}
	}
}
public class PostBook {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Arr a = new Arr(5);
		
		while(true) {
			System.out.println("A.�б� ģ�� ����");
			System.out.println("B.���� ���� ����");
			System.out.println("C.����");
			System.out.println("D.���");
			System.out.println("���� �Է�");
			char c=sc.next().charAt(0);
			
			switch(c) {
			case 'A':
				a.friend(c);
				break;
			case 'B':
				a.friend(c);
				break;
			case 'C':
				System.out.println("����");
				return;
			case 'D':
				a.all();
				break;
			}
		}

	}

}
