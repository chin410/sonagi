import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Lucky extends JFrame{
	JTextField jf= new JTextField();
	JTextField jff[]= new JTextField[7];
	JLabel jl = new JLabel("���? MAX=5");
	JLabel jll = new JLabel("��÷��ȣ�Է�");
	JLabel lo[]=new JLabel[35]; //�ζ� ��ȣ (�ִ� 5�� 35��)
	JButton[] b = new JButton[5];
	int lc=0; //�ζ� �� ����
	Lucky(){
		JLabel hi = new JLabel("����� �����!!");
		hi.setBounds(200, 0, 200, 50);
		
		Container c = getContentPane();
		c.setLayout(null);
		
		Color c1[]= new Color[5];
		c1[0]=new Color(80,208,208);
		c1[1]=new Color(190,30,62);
		c1[2]=new Color(255,198,57);
		c1[3]=new Color(255,127,80);
		c1[4]=new Color(127,255,212);
		
		
		c.setBackground(c1[4]);
		setTitle("LuckyLucky");
		
		// �ζ� �� ���� - + ��ư
		for(int i=0; i<b.length; i++) {
			b[i]=new JButton();
			b[i].setBackground(c1[i]);
		}
		b[0].setBounds(185,170,20,20);
		b[1].setBounds(295,170,20,20);
		
		//���� ��ư
		b[2]= new JButton("LUCKY");
		b[2].setBackground(c1[2]);
		b[2].setBounds(195,200,110,30);
		
		//�ٽý��� ��ư
		b[3]= new JButton("RETRY");
		b[3].setBackground(c1[3]);
		b[3].setBounds(100,400,110,30);
		b[3].setVisible(false);
		
		//��ȣ��÷ ��ư
		b[4]= new JButton("CHECK");
		b[4].setBackground(c1[2]);
		b[4].setBounds(280,400,110,30);
		b[4].setVisible(false);
		
		
		
		b[0].addActionListener(new bt0());
		b[1].addActionListener(new bt1());
		b[2].addActionListener(new bt2());
		b[3].addActionListener(new bt3());
		b[4].addActionListener(new bt4());
		
		//�ζǹ�ȣ ����
		int n=0;
		for(int i=0; i<lo.length; i++) {
			//��ȣ����
			int ran=(int)(Math.random()*45)+1;		
			lo[i]=new JLabel(Integer.toString(ran));
			//���ٸ��� �ߺ���ȣ ������ �ٲ��ֱ�
			for(int j=n; j<i; j++) {
				if(lo[i].getText().equals(lo[j].getText())) {
					i--;
					break;
				}
				if(i%7==0) {
					n+=7;
					break;
				}
			}
			
			lo[i].setVisible(false);
		}
		
		for(int i=0; i<jff.length; i++) {
			jff[i]=new JTextField();
			jff[i].setVisible(false);
		}
		jff[0].setBounds(47, 350, 20, 20);
		jff[1].setBounds(107, 350, 20, 20);
		jff[2].setBounds(167, 350, 20, 20);
		jff[3].setBounds(227, 350, 20, 20);
		jff[4].setBounds(287, 350, 20, 20);
		jff[5].setBounds(347, 350, 20, 20);
		jff[6].setBounds(407, 350, 20, 20);
		
		//�ζǹ�ȣ ��ġ����
		int x=50;
		int y=40;
		int w=20;
		int h=10;
		int j=0;
		for(int i=1; i<lo.length+1; i++) {
			lo[j].setBounds(x, y, w, y);
			x+=60;
			if(i%7==0 && i!=0) {
				x=50;
				y+=40;
			}
			j++;
		}

		jf.setBounds(210, 170, 80, 20);		
		jl.setBounds(205, 130, 200, 50);
		jll.setBounds(205, 305, 200, 50);
		jll.setVisible(false);

		c.add(hi);
		c.add(jl);
		c.add(jll);
		c.add(jf);
		
		for(int i=0; i<b.length; i++) {
			c.add(b[i]);
		}
		
		for(int i=0; i<lo.length; i++) {
			c.add(lo[i]);
		}
		
		for(int i=0; i<jff.length; i++) {
			c.add(jff[i]);
		}

		setSize(500,480);
		setVisible(true);
	}
	
	//�ζ� �� ���� -��ư
	class bt0 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			lc-=1;
			jf.setText(Integer.toString(lc));
		}
	}
	
	//�ζ� �� ���� +��ư
	class bt1 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			lc+=1;
			jf.setText(Integer.toString(lc));
		}
	}
	
	//���� ��ư
	class bt2 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			int c=0;
			for(int i=0; i<3; i++) {
				b[i].setVisible(false);
			}
			for(int i=0; i<jff.length; i++) {
				jff[i].setVisible(true);
			}
			jl.setVisible(false);
			jf.setVisible(false);
			
			b[3].setVisible(true);
			b[4].setVisible(true);
			jll.setVisible(true);
			c= Integer.valueOf(jf.getText());
			//0�Ʒ��� ������ 1�� ���
			if(c<0) {
				c=1;
			}
			//5�̻��̸� ������ 5�� ���
			else if(c>5) {
				c=5;
			}
			switch(c) {
			case 1: //1��
				for(int i=0; i<7; i++) {
					lo[i].setVisible(true);
				}
				break;
			case 2://2��
				for(int i=0; i<14; i++) {
					lo[i].setVisible(true);
				}
				break;
			case 3://3��
				for(int i=0; i<21; i++) {
					lo[i].setVisible(true);
				}
				break;
			case 4://4��
				for(int i=0; i<28; i++) {
					lo[i].setVisible(true);
				}
				break;
			case 5://5��
				for(int i=0; i<35; i++) {
					lo[i].setVisible(true);
				}
				break;
			}
			
		}
	}
	
	//�ٽý��� ��ư
	class bt3 implements ActionListener{
		public void actionPerformed(ActionEvent e) {	
			int n=0;
			
			for(int i=0; i<lo.length; i++) {
				//��ȣ �����
				int ran=(int)(Math.random()*45)+1;			
				lo[i].setText(Integer.toString(ran));
				lo[i].setForeground(Color.black);
				//���ٸ��� �ߺ���ȣ ������ �ٲ��ֱ�
				for(int j=n; j<i; j++) {
					if(lo[i].getText().equals(lo[j].getText())) {
						i--;
						break;
					}
					if(i%7==0) {
						n=7;
						break;
					}
				}
				
				lo[i].setVisible(false);
			}
			for(int i=0; i<jff.length; i++) {
				jff[i].setText("");
			}
			
			b[3].setVisible(false);
			b[4].setVisible(false);
			jll.setVisible(false);
			for(int i=0; i<jff.length; i++) {
				jff[i].setVisible(false);
			}
			
			for(int i=0; i<3; i++) {
				b[i].setVisible(true);
			}
			jf.setVisible(true);
			jl.setVisible(true);
			
		}
	}
	
	//�ζ���÷��ư
	class bt4 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			for(int i=0; i<lo.length; i++) {
				lo[i].setForeground(Color.black);
				for(int j=0; j<jff.length; j++) {
					if(lo[i].getText().equals(jff[j].getText())) {
					lo[i].setForeground(Color.red);
					}
				}

			}
			
		}
	}
	

	public static void main(String[] args) {
		new Lucky();

	}

}
