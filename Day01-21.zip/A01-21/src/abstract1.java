class Person{
	String name;
	String id;
	Person(String name){
		this.name=name;
	}
	void show() {
		System.out.println(name+" " +id);
	}
}
class Student extends Person{
	Student(String name){
		super(name);
	}
}

class Fruit{
	String a;
	int b;
	Fruit(String a,int b){
		this.a=a;
		this.b=b;
	}
	void show() {
		System.out.println(a+" " +b);
	}
	
}
class Apple extends Fruit{
	
	Apple(String a,int b){
		super(a, b);
	}

}
class Elec{
	String color;
	Elec(String color){
		this.color=color;
	}
}
class Note extends Elec{
	int number;
	Note(String c,int n){
		super(c);
		number=n;
	}
}
class Ipad extends Note{
	int size;
	Ipad(String c,int n,int s){
		super(c,n);
		size=s;
	}
	void show() {
		System.out.println(color+" "+number+" "+size);
	}
}
public class abstract1 {

	public static void main(String[] args) {
		
		Person p = new Student ("�ο�");
		//�ڽ��� �θ�Ŭ������ ����ȯ(up-casting)
		
		Student s = (Student)p;
		//�θ�Ŭ������ �ڽ�Ŭ������ ����ȯ(down-casting)
		
		System.out.println(s.name);
		
		Fruit f1 = new Apple("red",10);
		f1.show();
		
		Ipad a1= new Ipad("�����е� ����",4 , 80);
		a1.show();
		
		

	}

}
