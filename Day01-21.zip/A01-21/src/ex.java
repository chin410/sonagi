import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

class Student1{
	String first,last;
	Student1(String first,String last){
		this.first=first;
		this.last=last;
	}
	void pr() {
		System.out.println(first+" "+last);
	}
}
public class ex {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		FileWriter fw = new FileWriter("java.txt");
		
		//��ĳ�ʿ���
		InputStreamReader in = new InputStreamReader(System.in); //System in
		int a;
		System.out.println("�� ����");
		while((a=in.read())!=-1) { //read=int readLine=String
			fw.write(a);
		}
		fw.close();
		in.close();
		
		FileReader fr = new FileReader("java.txt");
		BufferedReader br = new BufferedReader(fr);
		String b;
		while((b=br.readLine())!=null) {
			System.out.println(b);
		}
		fr.close();
		br.close();
		

   Student1 s1=new Student1("��浿", "kim");

   Student1 s2=new Student1("�̱浿", "lee");

   s1.pr();
   s2.pr();    
		
		
		
		

	}

}
