import java.util.*;
abstract class Circlee{
	protected double r;
	
	Circlee(double r){
		this.r=r;
	}
	abstract double get();
	
}

class Cir extends Circlee{

	Cir(double r) {
		super(r);
		
	}
	double get() {
	
		return r;
	}
	
}
public class last {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Circlee c1[]=new Circlee[5];
		for(int i=0; i<c1.length; i++) {
			System.out.println("�� �Է�");
			double r=sc.nextDouble();
			c1[i]=new Cir(r);
			System.out.println(c1[i].get());
		}
		

	}

}
