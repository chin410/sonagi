class Music{
	String title,singer;
	Music(String title){
		this(title,"��ź");
	}
	Music(String title,String singer){
		this.singer=singer;
		this.title=title;
	}
	
}
/*class Cal{
	int a,b;
	
	static int add(int a,int b) {
		return a+b;
	}
	
	static int div(int a,int b) {
		return a/b;
	}
}*/
public class question345 {
	static int get(int a[][]){
		int top=0;
		for(int i=0; i<a.length; i++) {
			for(int j=0; j<a[i].length; j++) {
				if(top<a[i][j]) {
					top=a[i][j];
				}
			}
		}
		return top;
	}

	public static void main(String[] args) {
		
			Music m=new Music("On", "BTS");

			System.out.println(m.title+ "," +m.singer); 

			Music m1=new Music("00:00");

			System.out.println(m1.title+"," +m1.singer);  
			
			/*int a=Cal.add(10,5); //��

			int b=Cal.div(10,5); //��

			System.out.println(a +" " +b);*/
			
			
			for(int i=0;i<4;i++) {
				int n=0; 
				for(int j=0; j<3-i; j++) {
				System.out.print(" ");
				}
				for(int j=0; j<i+(i+1);j++) {
					System.out.print(n);
					n++;
				}
				System.out.println();
			}
			System.out.println();
			int [][] grade = {{55,60,65},{85,90,95}};
			
			int high;
			high=get(grade);
			System.out.println("���� ���� ������ "+high+"�� �Դϴ�.");

	}

}
