import java.util.*;
public class test {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
	int a=10,b=4;
	
	if(a<b) {
		System.out.println(a/b);
	}else {
		System.out.println(a%b);
	}
	
	System.out.println("ù��° ��");
	double c=sc.nextDouble();
	System.out.println("�ι�° ��");
	double d=sc.nextDouble();
	System.out.println(c+"+"+d+"="+(c+d));
	System.out.println(c+"-"+d+"="+(c-d));
	System.out.println(c+"X"+d+"="+(c*d));
	System.out.println(c+"/"+d+"="+(c/d));
	
	System.out.println("����� ���̴�?");
	int i=sc.nextInt();
	
	if(i>20) {
		System.out.println("�����Դϴ�.");
	}else {
		System.out.println("�����Դϴ�.");
	}

	}

}
