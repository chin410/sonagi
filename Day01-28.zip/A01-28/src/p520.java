import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class p520 extends JFrame{
	p520(){
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		
		JTextField txt = new JTextField(10);
		JTextArea area = new JTextArea(10,10);
		
		c.add(txt);
		c.add(area);
		
		txt.addKeyListener(new KeyAdapter() {
		public void keyReleased(KeyEvent e) {
			int key=e.getKeyCode();
			
			if(key==KeyEvent.VK_ENTER) {
			String str = txt.getText();
			String str1=str.toUpperCase();
			area.setText(area.getText()+str1+"\n");
			txt.setText("");
		}
		
			
	}
			
		});
		
		setSize(300,300);
		setVisible(true);
		
		
		
	}
	public static void main(String[] args) {
		new p520();
		

	}

}
