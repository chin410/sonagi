import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
class text implements ActionListener{
	JTextArea jt;
	 text(JTextArea jt){
		this.jt=jt;
	}
	 public void actionPerformed(ActionEvent e) {
		 jt.setText("");
		 jt.append("�����Է�");
	 }
	
	
}
public class Textarea {

	public static void main(String[] args) {
		JFrame j = new JFrame();
		j.setLayout(new FlowLayout());
		
		JTextArea jt= new JTextArea(10,20);
		jt.append("�Է�");
		jt.setLineWrap(true);
		
		JButton b1= new JButton("����");
		
		b1.addActionListener(new text(jt));
		j.add(b1);
		j.add(jt);
		
		j.setSize(500,500);
		j.setVisible(true);

	}

}
