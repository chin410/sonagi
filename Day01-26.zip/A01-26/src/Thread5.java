class Cook{
	String food;
	boolean send=false;
	
	void set(String f) {
		food=f;
		send=true;
	synchronized(this) {
		notifyAll();
	}
	}
	String get() {
		if(send==false) {
			try {
				synchronized (this) {
					wait();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return food;
	}
}

class Chef extends Thread{ //�丮��
	 Cook c;
	 Chef(Cook c){
	  this.c=c;
	 }
	 public void run() {
	  c.set("����");

	 }

	}

class Customer extends Thread{
	Cook c;
	Customer(Cook c){
		this.c=c;
	}
	public void run() {
		System.out.println(c.get());
	}
}

public class Thread5 {

	public static void main(String[] args) {
		Cook co = new Cook();
		Customer cu1= new Customer(co);
		Customer cu2= new Customer(co);
		Chef c=new Chef(co);
		
		try {
			cu1.start();
			cu2.start();
			Thread.sleep(1000);
			c.start();
			
			cu1.join();
			cu2.join();
			c.join();
		}catch(Exception e) {}
	}

}
