interface Cal{
	int total(int a,int b);
	int big(int a,int b);
}
class Calcu implements Cal{
	int a,b;
	public int total(int a, int b) {
		int n=0;
		
		for(int i=a; i<=b; i++) {
			n+=i;
		}
		return n;
	}

	
	public int big(int a, int b) {
		int n= a>b ? a:b;
		return n;

	}

}
public class ex2 {

	public static void main(String[] args) {
		Calcu cu = new Calcu();
		
		System.out.println(cu.big(3, 5));
		System.out.println(cu.total(1, 10));

	}

}
