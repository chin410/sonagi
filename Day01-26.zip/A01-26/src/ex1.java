class Total{
int sum;
Total(){
   sum=0;
   }
void total(int n){
  sum+=n; 
  }
int get(){
  return sum; 
  }
}

class AThread extends Thread{
	Total t;
	int a,b;
	AThread(Total t,int a,int b){
		this.t=t;
		this.a=a;
		this.b=b;
	}

	public void run() {
		int hap=0;
		for(int i=a; i<=b; i++) {
			hap+=i;
		}
		System.out.println(hap);
		/*try {
			synchronized (this) {
			notifyAll();
			}
		}catch(Exception e) {}*/
		
	}
	
}
public class ex1 {

	public static void main(String[] args) throws InterruptedException {
		  Total t=new Total();
		  AThread a=new AThread(t, 1, 50);
		  AThread b=new AThread(t, 51, 100);
		  //Thread t1=new Thread(a); //Runnable�� �����带 ��������
		  //Thread t2=new Thread(b);
		  //t1.start();
		  //t2.start();
		  
		  a.start();   //�����̺� �Ⱦ���
		  b.start();
		  a.join();
		  b.join();

	}

}
