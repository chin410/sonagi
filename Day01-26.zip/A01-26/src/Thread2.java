abstract class Profile{
	abstract void add(String name,String id);
	abstract String check(String id);
}
class Person{
	String name,id;
	
	Person(String a,String b){
		name=a;
		id=b;
	}
	String getname() {
	return name;	
	}
	
	String getid() {
		return id;
	}
}
class Per extends Profile{
	Person ary[]; //��ü �迭 ����
	int n;
	Per(int n){
		ary=new Person[n];
	}
	 void add(String name,String id) {
		ary[n]=new Person(name,id);
		n++;
	}
	String check(String id) {
		for(int i=0; i<n; i++) {
			if(id.compareTo(ary[i].getid())==0) {
				return ary[i].getname();
			}
		}
		return null;
	}

}
public class Thread2 {

	public static void main(String[] args) {
		Profile p = new Per(5);
		p.add("�ο�", "123");
		p.add("�Ƹ�", "456");
		p.add("�̿�", "789");
		
		System.out.println(p.check("123"));
		System.out.println(p.check("456"));
		System.out.println(p.check("789"));

	}

}
