class Circle {
	int radius;
	
	Circle(int a){
		radius=a;
	}
	public String toString() { //���ڿ� ��ȯ
		return radius+" ";
	}
	public boolean equals(Object ob) {
		if(this.radius==(((Circle)ob).radius)) {
		return true;
		}
		return false;
	}
}

interface Po{
	abstract void pr(int b,String a);
	abstract void pr(String a);
	
}
class Point implements Po{
	int a;
	String b;

	public void pr(int b,String a) {
		System.out.println(a+"å��"+b+"��");
	}

	
	public void pr(String a) {
		System.out.println(a);	
	}
}

public class ex {

	public static void main(String[] args) {
		Circle a=new Circle(30);

        Circle b=new Circle(30);

        System.out.println("������"+a);

        System.out.println("������"+b);

        

        if(a.equals(b)) {

                   System.out.println("���� ��"); 
                   }

        else {

                   System.out.println("�ٸ� ��");
                   }
        
        Po p=new Point();

        p.pr(30000,"java");   

        p.pr("python");
        

	}

}
