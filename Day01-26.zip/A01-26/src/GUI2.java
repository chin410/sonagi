import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GUI2 extends JFrame{
GUI2(){
	setSize(300,300);
	Container c = getContentPane();
	c.setLayout(new FlowLayout());
	
	JLabel j = new JLabel("�ȳ�");
	ImageIcon ic = new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/abc.jpg"); //�̹��� ����
	JLabel i = new JLabel(ic);
	
	c.add(j);
	c.add(i);
	
	setVisible(true);
}
	public static void main(String[] args) {
		new GUI2();

		
	}

}
