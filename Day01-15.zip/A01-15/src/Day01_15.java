import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Day01_15 {
	

	
	
	static int big(int  grade[][] ,int b,int c) {
		int max=0;
		for(int i=0; i<grade.length; i++) {
			for(int j=0; j<grade[i].length; j++) {
			if(max<grade[i][j]) {
				max=grade[i][j];
			}
			}
		}
		return max;
	}
	
	//3��
	static int adder(int a, int b) {
		int c=a+b;
		return c;
	}
	
	static double exp(double a) {
		double c= a*a;
		return c;
	}
	
	
	//4��
	static double one2(int a) {
		double c=a*3.14;
		return c;
	}
	
	static void one(int a) {
		System.out.println(a*3.14);
	}
	
	
	
	public static void main(String[] args) throws IOException{
		Scanner sc = new Scanner(System.in);
	          
	          //6��
	         /* String a="C++";
	          String b="ddd,JAVA";
	          int c=a.length();
	          String d;
	          String e [];
	          System.out.println(c);
	          System.out.println(a.substring(1,3));
	          System.out.println(b.substring(3,4));
	          d=b.replace("JAVA","C#");
	          System.out.println(d);
	          e=b.split(",");
	          System.out.println(e[0]);*/
		
	          
	          /*try {
	        	  System.out.println("ù��° �� �Է�");
	        	  int a= sc.nextInt();
	        	  System.out.println("������ �Է�");
	        	  String b = sc.next();
	        	  System.out.println("ù��° �� �Է�");
	        	  int c =sc.nextInt();
	        	  
	        	  switch(b) {
	        	  case "*" :
	        		  System.out.println(a*c);
	        		  break;
	        	  case "/" :
	         		  if(a==0 || c==0) {
	        			  throw new Exception("���� �ϳ��� 0 �̸� �ȵ�");
	        		  }
	        		  System.out.println(a/c);
	        		  break;
	        	  
	        	  }
	          }catch(Exception e){
	        	  System.out.println("����");
	        	  System.out.println(e.getMessage());
	        	  
	          }*/
		
		/*int ary[] = {3,2,1,6,5};
		int temp;
		
		for(int i=0; i<4; i++) {
			for(int j=i+1; j<5; j++) {
				if(ary[i]>ary[j]) {
					temp=ary[i];
					ary[i]=ary[j];
					ary[j]=temp;
				}
			}
		}*/
		
		/*char a='S';
		char b='W';
		
		FileWriter out = new FileWriter("a.txt"); //���ϻ���
		
		out.close();*/
		
		char ary [] = new char [10];
		int cnt;
		FileReader in = new FileReader("a.txt");
		cnt=in.read(ary,0,ary.length);
		
	    for(int i=0; i<cnt; i++) {
	    	System.out.println(ary[i]);
	    }
	        in.close();
	          
	          
	          

	}
	
}
