package co.springbreakers.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import co.springbreakers.servies.ImgServie;

@ControllerAdvice
public class allException {
	
	
	/*  @Autowired ImgServie iser;
	  
	  @ExceptionHandler(Exception.class) public String excep(Exception e, Model
	  model) { System.err.println(e.getMessage());
	  
	  model.addAttribute("errbackimg", iser.getpath("에러배경"));
	 
	  return "errpage"; }
	 */

}
