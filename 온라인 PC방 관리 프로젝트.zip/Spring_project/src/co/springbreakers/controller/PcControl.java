package co.springbreakers.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import co.springbreakers.beans.Pc_Main1;
import co.springbreakers.beans.Pc_maneger;
import co.springbreakers.beans.Pc_user;
import co.springbreakers.beans.pc_time;
import co.springbreakers.mapper.PcMapper;
import co.springbreakers.servies.ImgServie;
import net.sf.json.JSONArray;

@Configuration
@RequestMapping("/pcmain")
public class PcControl {

	@Autowired
	PcMapper pcmap;
	
	@Resource(name = "mloginBean")
	private Pc_maneger mloginBean;
	
	@Resource(name = "uloginBean")
	private Pc_user uloginBean;
	
	@Autowired
	ImgServie iser;
	
	@GetMapping("/pc_main1")
	public String pc(@RequestParam("pc_name") String pc_name, Model model) {
		
		
		String pcname = mloginBean.getPc_name();
		if(pcname == null) {
			pcname = pc_name;
		}
		
		String colums_name_sql = "select column_name from user_tab_columns where table_name = upper('pc_" + pc_name + "_table')";
		String resultsql = "select pc_name||','||pc_b_number||','||numcol||','||numrow||','||checktable";
		
		List<String> colums_name = pcmap.colums_name(colums_name_sql);
		int colums_count = colums_name.size();
		
		
		for(int i = 5; i < colums_count; i++) {
			if(i == colums_count - 1) {
				resultsql += "||','||" + colums_name.get(i) + " from pc_" + pcname + "_table";
			} else {
				resultsql += "||','||" + colums_name.get(i);
			}
		}
		
		System.out.println(resultsql);
		
		String[] result = pcmap.pc_result(resultsql).split(",");
		String[] checktable = result[4].split("-");
		ArrayList<String> alltable = new ArrayList<String>();
		
		int numcol = Integer.parseInt(result[2]);
		int numrow = Integer.parseInt(result[3]);
		
		for(int i = 0; i < numcol; i++) {
			for(int j = 0; j < numrow; j++) {
				alltable.add("t"+i+"_"+j);
			}
		}
		
		
		List<Pc_Main1> pcmainlist = new ArrayList<Pc_Main1>();
		
		for(int i = 5; i < result.length; i++) {
			String[] splitdata = result[i].split("-");
			Pc_Main1 pcmain = new Pc_Main1(splitdata[0], splitdata[1], splitdata[2]);
			pcmainlist.add(pcmain);
		}
		
		JSONArray jsonArray = new JSONArray();
		
		System.out.println(pcmainlist.get(4).getUsertime());
		
		model.addAttribute("pc_name",result[0]);
		model.addAttribute("pc_b_number", result[1]);
		model.addAttribute("numcol", numcol);
		model.addAttribute("numrow", numrow);
		model.addAttribute("checktable", checktable);
		model.addAttribute("alltable", alltable);
		model.addAttribute("jsonList", jsonArray.fromObject(pcmainlist));
		model.addAttribute("pcmain1",iser.getpath("등록1배경"));
		
		
		return "pcmain/pc_main1";
	}
	

	@RequestMapping(value = "/pc_maincategory")
	public String category(@RequestParam("category") String category, @RequestParam("pc_name") String pc_name ,Model model) {
		
		model.addAttribute("pc_name", pc_name);
		 model.addAttribute("side",iser.getpath("사이드버튼"));
		if(category.equals("cafe")) {
			String sql="select pc_food_path from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='카페'";
			String sql1="select pc_food_name from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='카페'";
			String sql2="select pc_food_price from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='카페'";
			
			List<String> cafe=pcmap.getfoodpath(sql);
			List<String> cafen=pcmap.getfoodpath(sql1);
			List<String> cafep=pcmap.getfoodpath(sql2);
			
			for(int i=0; i<cafe.size(); i++) {
				model.addAttribute("food"+i, cafe.get(i));
				model.addAttribute("foodn"+i, cafen.get(i));
				model.addAttribute("foodp"+i, cafep.get(i));
				model.addAttribute("pc_name", pc_name);
			}
		} else if(category.equals("drink")) {
			String sql="select pc_food_path from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='음료'";
			String sql1="select pc_food_name from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='음료'";
			String sql2="select pc_food_price from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='음료'";
			
			List<String> drink=pcmap.getfoodpath(sql);
			List<String> drinkn=pcmap.getfoodpath(sql1);
			List<String> drinkp=pcmap.getfoodpath(sql2);
			
			for(int i=0; i<drink.size(); i++) {
				model.addAttribute("food"+i, drink.get(i));
				model.addAttribute("foodn"+i, drinkn.get(i));
				model.addAttribute("foodp"+i, drinkp.get(i));
				model.addAttribute("pc_name", pc_name);
			}
		}else if(category.equals("siksa")) {
			String sql="select pc_food_path from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='식사류'";
			String sql1="select pc_food_name from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='식사류'";
			String sql2="select pc_food_price from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='식사류'";
			
			List<String> siksa=pcmap.getfoodpath(sql);
			List<String> siksan=pcmap.getfoodpath(sql1);
			List<String> siksap=pcmap.getfoodpath(sql2);
			
			for(int i=0; i<siksa.size(); i++) {
				model.addAttribute("food"+i, siksa.get(i));
				model.addAttribute("foodn"+i, siksan.get(i));
				model.addAttribute("foodp"+i, siksap.get(i));
				model.addAttribute("pc_name", pc_name);
			}
		}else if(category.equals("lamen")) {
			String sql="select pc_food_path from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='라면'";
			String sql1="select pc_food_name from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='라면'";
			String sql2="select pc_food_price from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='라면'";
			
			List<String> lamen=pcmap.getfoodpath(sql);
			List<String> lamenn=pcmap.getfoodpath(sql1);
			List<String> lamenp=pcmap.getfoodpath(sql2);
			
			for(int i=0; i<lamen.size(); i++) {
				model.addAttribute("food"+i,  lamen.get(i));
				model.addAttribute("foodn"+i, lamenn.get(i));
				model.addAttribute("foodp"+i, lamenp.get(i));
				model.addAttribute("pc_name", pc_name);
			}
		}else if(category.equals("gansik")) {
			String sql="select pc_food_path from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='간식류'";
			String sql1="select pc_food_name from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='간식류'";
			String sql2="select pc_food_price from pc_table_food where pc_name='"+pc_name+"' and pc_food_category='간식류'";
			
			List<String> gansik=pcmap.getfoodpath(sql);
			List<String> gansikn=pcmap.getfoodpath(sql1);
			List<String> gansikp=pcmap.getfoodpath(sql2);
			
			for(int i=0; i<gansik.size(); i++) {
				System.out.println(gansik.get(i));
				model.addAttribute("food"+i, gansik.get(i));
				model.addAttribute("foodn"+i, gansikn.get(i));
				model.addAttribute("foodp"+i, gansikp.get(i));
				model.addAttribute("pc_name", pc_name);
			}

		}
		
		
		return "pcmain/pc_maincategory";
	}
	
	
}
