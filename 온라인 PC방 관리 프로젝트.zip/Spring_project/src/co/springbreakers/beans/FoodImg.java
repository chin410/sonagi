package co.springbreakers.beans;

public class FoodImg {
	
	private String pc_name;
	private String pc_b_number;
	private String pc_food_category;
	private String pc_food_name;
	private String pc_food_price;
	private String pc_food_path;
	
	
	public String getPc_name() {
		return pc_name;
	}
	public void setPc_name(String pc_name) {
		this.pc_name = pc_name;
	}
	public String getPc_b_number() {
		return pc_b_number;
	}
	public void setPc_b_number(String pc_b_number) {
		this.pc_b_number = pc_b_number;
	}
	public String getPc_food_category() {
		return pc_food_category;
	}
	public void setPc_food_category(String pc_food_category) {
		this.pc_food_category = pc_food_category;
	}
	public String getPc_food_name() {
		return pc_food_name;
	}
	public void setPc_food_name(String pc_food_name) {
		this.pc_food_name = pc_food_name;
	}
	public String getPc_food_price() {
		return pc_food_price;
	}
	public void setPc_food_price(String pc_food_price) {
		this.pc_food_price = pc_food_price;
	}
	public String getPc_food_path() {
		return pc_food_path;
	}
	public void setPc_food_path(String pc_food_path) {
		this.pc_food_path = pc_food_path;
	}
	
}
