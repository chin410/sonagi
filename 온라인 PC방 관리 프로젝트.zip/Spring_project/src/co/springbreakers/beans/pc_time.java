package co.springbreakers.beans;


import java.util.ArrayList;
import java.util.List;

public class pc_time {
	
	private String pc_name;
	
	private String pc_b_number;
	
	private String pc_time_text;
	
	private String pc_time;
	
	private String pc_time_price;

	public String getPc_name() {
		return pc_name;
	}

	public void setPc_name(String pc_name) {
		this.pc_name = pc_name;
	}

	public String getPc_b_number() {
		return pc_b_number;
	}

	public void setPc_b_number(String pc_b_number) {
		this.pc_b_number = pc_b_number;
	}


	public String getPc_time_text() {
		return pc_time_text;
	}

	public void setPc_time_text(String pc_time_text) {
		this.pc_time_text = pc_time_text;
	}

	public String getPc_time() {
		return pc_time;
	}

	public void setPc_time(String pc_time) {
		this.pc_time = pc_time;
	}

	public String getPc_time_price() {
		return pc_time_price;
	}

	public void setPc_time_price(String pc_time_price) {
		this.pc_time_price = pc_time_price;
	}




	
}
