package co.sp.beans;

public class Tdata2 {
	private String da3;
	private String da4;
	public String getDa3() {
		return da3;
	}
	public void setDa3(String da3) {
		this.da3 = da3;
	}
	public String getDa4() {
		return da4;
	}
	public void setDa4(String da4) {
		this.da4 = da4;
	}
	
}
