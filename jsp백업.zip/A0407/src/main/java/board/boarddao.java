package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import bean.Bean;

public class boarddao {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public void getcon() {
		try{			
			Context ctx=new InitialContext();
			Context envctx=(Context)ctx.lookup("java:comp/env");	//리소스 이름을 lookup으로 찾을떄 앞에 붙는 접두사
			DataSource ds=(DataSource)envctx.lookup("jdbc/pool");
			
		    con=ds.getConnection();
		    
			
	}catch(Exception e) {
		e.printStackTrace();
	}
}
	
	public void boinsert(boardbean bo) {

		
		int ref=0;
		int re_step=1;
		int re_level=1;
		
		try {
			getcon();
			String rsql="select max(ref) from board";
			
			pstmt=con.prepareStatement(rsql);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				ref=rs.getInt(1)+1;
			}
			
			//board_seq.up 시퀀스 등록
			String sql="insert into board values(up.NEXTVAL,?,?,?,?,sysdate,?,?,?,0,?)";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, bo.getWriter());
			pstmt.setString(2, bo.getEmail());
			pstmt.setString(3, bo.getSubject());
			pstmt.setString(4, bo.getPassword());
			
			pstmt.setInt(5, ref);
			pstmt.setInt(6, re_step);
			pstmt.setInt(7, re_level);
			
			pstmt.setString(8, bo.getContent());
			
			pstmt.executeQuery();
			con.close();
			
	
			
		}catch(Exception e) {
			
		}
	}
	
	
	public Vector<boardbean> boselect(int start, int end){
		Vector <boardbean> v = new Vector <boardbean>();
		getcon();
		
		try {
			String sql=("select * from (select A.*, Rownum Rnum from (select * from board order by ref desc, re_level asc)A) where Rnum>=? and Rnum<=?");
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				boardbean bo = new boardbean();
				bo.setNum(rs.getInt(1));
				bo.setWriter(rs.getString(2));
				bo.setEmail(rs.getString(3));
				bo.setSubject(rs.getString(4));
				bo.setPassword(rs.getString(5));
				bo.setDate(rs.getDate(6).toString());
				bo.setRef(rs.getInt(7));
				bo.setRe_step(rs.getInt(8));
				bo.setRe_level(rs.getInt(9));
				bo.setReadcount(rs.getInt(10));
				bo.setContent(rs.getString(11));
				v.add(bo);
			}
			con.close();
		}catch(Exception e) {
			
		}
		return v;
	}
	
	public boardbean onesel(int num) {
		boardbean bo = new boardbean();
		getcon();
		
		try {
			
			
			 String readsql="update board set readcount=readcount+1 where num=?";
	          pstmt=con.prepareStatement(readsql);
	          pstmt.setInt(1, num);
	          pstmt.executeUpdate();
	          

			
			
			String sql="select * from board where num=?";
			
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setInt(1, num);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				bo.setNum(rs.getInt(1));
				bo.setWriter(rs.getString(2));
				bo.setEmail(rs.getString(3));
				bo.setSubject(rs.getString(4));
				bo.setPassword(rs.getString(5));
				bo.setDate(rs.getDate(6).toString());
				bo.setRef(rs.getInt(7));
				bo.setRe_step(rs.getInt(8));
				bo.setRe_level(rs.getInt(9));
				bo.setReadcount(rs.getInt(10));
				bo.setContent(rs.getString(11));
			}
			con.close();
		}catch(Exception e) {
			
		}
		return bo;

	}
	
	public void reinsert(boardbean bo) {//내가 답글을 달고싶은 글의정보

		
		int ref=bo.getRef();
		int re_step=bo.getRe_step();
		int re_level=bo.getRe_level();
		
		try {
			getcon();
			String strsql="update board set re_level=re_level+1 where ref=? and re_level > ?"; //내가 답글을 달고싶은 글보다 레벨높은애들 싹다 +1
			
			pstmt=con.prepareStatement(strsql);
			pstmt.setInt(1, ref);
			pstmt.setInt(2, re_level);
			
			pstmt.executeUpdate();
			
			
			String sql="insert into board values(up.NEXTVAL,?,?,?,?,sysdate,?,?,?,0,?)";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, bo.getWriter());
			pstmt.setString(2, bo.getEmail());
			pstmt.setString(3, bo.getSubject());
			pstmt.setString(4, bo.getPassword());
			
			pstmt.setInt(5, ref);
			//댓글이니까 스탭 레벨 1씩 더해줌
			pstmt.setInt(6, re_step+1); //내가 답글을 달고싶은 글의 스탭+1 (새로넣을 답글) 스탭+1 
			pstmt.setInt(7, re_level+1); //내가 답글을 달고싶은 글의 레벨+1 (새로넣을 답글) 레벨+1 
			
			pstmt.setString(8, bo.getContent());
			
			pstmt.executeQuery();
			con.close();
			
	
			
		}catch(Exception e) {
			
		}
	}
	
	public boardbean oneupdateboard(int num) {
		boardbean bo= new boardbean();
		getcon();
		try {
			String sql="select * from board where num=?";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setInt(1, num);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				bo.setNum(rs.getInt(1));
				bo.setWriter(rs.getString(2));
				bo.setEmail(rs.getString(3));
				bo.setSubject(rs.getString(4));
				bo.setPassword(rs.getString(5));
				bo.setDate(rs.getDate(6).toString());
				bo.setRef(rs.getInt(7));
				bo.setRe_step(rs.getInt(8));
				bo.setRe_level(rs.getInt(9));
				bo.setReadcount(rs.getInt(10));
				bo.setContent(rs.getString(11));
			}
			con.close();
			
		}catch(Exception e) {
			
		}
		return bo;
	}
	
	public String getpass(int num) {
		String pass="";
		getcon();
		try {
			String sql="select password from board where num=?";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setInt(1, num);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				pass=rs.getString(1);
			}
		}catch(Exception e) {
			
		}
		return pass;
	}
	
	public void updateboard(boardbean bo) {
		getcon();
		
		try {
			String sql="update board set subject=?,content=? where num=?";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, bo.getSubject());
			pstmt.setString(2, bo.getContent());
			pstmt.setInt(3, bo.getNum());
			
			pstmt.executeUpdate();
		}catch(Exception e) {
			
		}
	}
	
	public void deleteboard(int num) {
		getcon();		
		try {
			String sql="delete from board where num=?";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setInt(1, num);
			
			pstmt.executeUpdate();
			con.close();
		}catch (Exception e) {
		
		}
		
	}
	
	public int allcount() {
		getcon();
		
		int cnt=0;
		
		try {
			String sql="select count(*) from board";
			
			pstmt=con.prepareStatement(sql);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				cnt=rs.getInt(1);
			}
		}catch(Exception e ) {
			
		}
		return cnt;
	}
	

}
