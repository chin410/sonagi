package bean;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JoinServlet
 */
@WebServlet("/JoinServlet")
public class JoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JoinServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      response.setContentType("text/html; charset=UTF-8");
	      PrintWriter out=response.getWriter();
	      
	      String name=request.getParameter("name");
	      String jumin1=request.getParameter("jumin1");
	      String jumin2=request.getParameter("jumin2");
	      String pass1=request.getParameter("pass1");
	      String pass2=request.getParameter("pass2");
	      String email1=request.getParameter("email1");
	      String email2=request.getParameter("email2");
	      String email3=request.getParameter("email3");
	      String mail=request.getParameter("mail");
	      String addr1=request.getParameter("addr1");
	      String addr2=request.getParameter("addr2");
	      String tel=request.getParameter("tel");
	      String job=request.getParameter("job");
	      String r1=request.getParameter("r1");
	      out.print("<html><body>");
	      out.print("<table border='1'><tr><td>�̸�: "+name+"</td></tr>");
	      out.print("<tr><td>�ֹι�ȣ: "+jumin1+"-"+jumin2+"</td></tr>");
	      out.print("<tr><td>��й�ȣ: "+pass1+"</td></tr>");
	      out.print("<tr><td>�̸���: "+email1+"@"+email3+"</td></tr>");
	      out.print("<tr><td>�����ȣ: "+mail+"</td></tr>");
	      out.print("<tr><td>�ּ�: "+addr1+addr2+"</td></tr>");
	      out.print("<tr><td>�޴���: "+tel+"</td></tr>");
	      out.print("<tr><td>����: "+job+"</td></tr>");
	      out.print("<tr><td>���ſ���: "+r1+"</td></tr>");
	      out.print("</table>");
	      out.print("</html></body>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
