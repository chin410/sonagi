
package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class DBDAO {
	String id="sys as sysdba";
	String pw="dlsdud12";
	String url="jdbc:oracle:thin:@172.30.1.13:1521/xepdb1";		
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public void getCon() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con=DriverManager.getConnection(url, id, pw);
			
		}catch(Exception e) {}
	}
	
	public void DBinsert(DBset set) {
		try {
			getCon();
			
			String sql="insert into members values(?,?,?,?,?,?,?,?)";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1,set.getId() );
			pstmt.setString(2,set.getPass() );
			pstmt.setString(3,set.getEmail() );
			pstmt.setString(4,set.getTel() );
			pstmt.setString(5,set.getHobby() );
			pstmt.setString(6,set.getJob() );
			pstmt.setString(7,set.getAge() );
			pstmt.setString(8,set.getInfo() );
			
			pstmt.executeQuery();
		}catch(Exception e) {}
	}
	
	
	public Vector<DBset> sel(){
		Vector<DBset> v = new Vector<DBset>();
		try {
			getCon();
			
			String sql="select * from members";
			
			pstmt=con.prepareStatement(sql);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				DBset dbs = new DBset();
				dbs.setId(rs.getString(1));
				dbs.setPass(rs.getString(2));
				dbs.setEmail(rs.getString(3));
				dbs.setTel(rs.getString(4));
				dbs.setHobby(rs.getString(5));
				dbs.setJob(rs.getString(6));
				dbs.setAge(rs.getString(7));
				dbs.setInfo(rs.getString(8));
				v.add(dbs);
			}
			
		}catch(Exception e) {}
		return v;
	}
	
	public DBset onesel(String id){
		DBset dbs = new DBset();
		try {
			getCon();
			String sql="Select * from members where id=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				dbs.setId(rs.getString(1));
				dbs.setPass(rs.getString(2));
				dbs.setEmail(rs.getString(3));
				dbs.setTel(rs.getString(4));
				dbs.setHobby(rs.getString(5));
				dbs.setJob(rs.getString(6));
				dbs.setAge(rs.getString(7));
				dbs.setInfo(rs.getString(8));
				
			}
			
			
		}catch(Exception e) {}
		
		return dbs;
	}
	
	public String pass(String id) {
		getCon();
		String pass="";
		try {
			
			String sql="select pass from members where id=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				pass=rs.getString(1);
			}
			con.close();
		}catch(Exception e) {
			
		}
		return pass;
	}
	
	public void DBupdate(DBset set) {
		try {
			getCon();
			
			String sql="update members set age=?,info=? where id=?";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1,set.getAge());
			pstmt.setString(2,set.getInfo());
			pstmt.setString(3,set.getId());
				
			pstmt.executeQuery();
			con.close();
		}catch(Exception e) {}
	}
	
	public void DBdelete(DBset set) {
		try {
			getCon();
			
			String sql="delete members where id=?";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1,set.getId());
				
			pstmt.executeQuery();
			con.close();
		}catch(Exception e) {}
	}

}
