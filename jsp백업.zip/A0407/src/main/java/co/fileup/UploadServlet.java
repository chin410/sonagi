package co.fileup;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet({ "/UploadServlet", "/up.do" })
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	      request.setCharacterEncoding("UTF-8");
	      response.setContentType("text/html; charset=UTF-8");
	      
	      PrintWriter out=response.getWriter();
	      
	      String save="upload";
	      int size=5*1024*1024;
	      String encType="UTF-8";
	      
	      
	      //서버상 실제 디렉토리 찾아내기
	      ServletContext context=getServletContext();
	      String filepath=context.getRealPath(save);
	      
	      
	      System.out.println(filepath);
	      
	      try {
	         MultipartRequest multi
	            =new MultipartRequest
	   (request,filepath,size,encType,new DefaultFileRenamePolicy());
	   
	         //업로드된 파일 이름 얻어내기(서버에 실제로 업로드 된 파일의 이름)
	         
	      Enumeration files=multi.getFileNames();
	         
	      while(files.hasMoreElements()) {
	         String file=(String)files.nextElement();
	         String file_name=multi.getFilesystemName(file);
	         
	         String origin=multi.getOriginalFileName(file);
	         //사용자가 업로드 한 파일의 원본이름
	         
	         out.print(file_name+"<br>");
	         out.print(origin);   
	         
	      }
	   }catch(Exception e) {
	      System.out.println("예외 발생");
	   }

				
	}

}
