/*
 */

function chk(){
	var bir=document.getElementById("birth").value;
	var nam=document.getElementById("name").value;
	
	if(isNaN(bir)==true){
		alert("생년월일은 숫자만 입력하세요");
		return false;
	}else if(bir.length!=6){
		alert("생년월일은 6자로 입력하세요");
		return false;
	}else{
		return true;
	}
	

	
	
}