package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;




public class DBConnectionMgr {
	PreparedStatement pstmt;
	Connection con;
	ResultSet rs;
	
	/*String url="jdbc:oracle:thin:@172.30.1.13:1521/xepdb1";
	String id="sys as sysdba";
	String pw="dlsdud12";*/
	
	
	public void getcon() {
		try{

			
			/*Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con=DriverManager.getConnection(url,id,pw);*/
			
			
			Context ctx=new InitialContext();
			Context envctx=(Context)ctx.lookup("java:comp/env");
			
		
			DataSource ds=(DataSource)envctx.lookup("jdbc/pool");
			
		    con=ds.getConnection();
		    
			
	}catch(Exception e) {
		e.printStackTrace();
	}
}
	
	//bean클래스를 메게변수로 회원가입할때 입력한 자료들 DB에저장
	public void meminsert(MemberBean mem) {
		getcon();
		try {
			
			String sql="insert into member values(?,?,?,?,?,?,?,?,?,?)";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1,mem.getId());
			pstmt.setString(2,mem.getPwd());
			pstmt.setString(3,mem.getName());
			pstmt.setString(4,mem.getGender());
			pstmt.setString(5,mem.getEmail());
			pstmt.setString(6,mem.getBirth());
			pstmt.setString(7,mem.getZipcode());
			pstmt.setString(8,mem.getAddress());
			pstmt.setString(9,mem.getHobby());
			pstmt.setString(10,mem.getJob());
			pstmt.executeQuery();
			con.close();
			}catch(Exception e){
				e.printStackTrace();
			
			
		}

		
		}
	
	//DB에있는 id들을 가져와서 백터로 반환 
	public Vector<MemberBean> idchk(){
		Vector<MemberBean> v = new Vector<MemberBean>();
		getcon();
		try {
			String sql="select id from member";
			
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				MemberBean mem =new MemberBean();
				mem.setId(rs.getString(1));
				v.add(mem);
			}
			
		}catch(Exception e) {
			
		}
		return v;
	}
	
	//id를 매게변수로 그 id에대한 비밀번호를 반환
	public String logchk(String id){
		String pw="";
		getcon();
		try {
			String sql="select pwd from member where id=?";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				pw=rs.getString(1);

			}
			
		}catch(Exception e) {
			
		}
		return pw;
	}
	
	//DB에있는 id들을 가져와서 어레이리스트로 빈환 그냥해봄
	public ArrayList<MemberBean> joongbok(){
		ArrayList<MemberBean> a =new ArrayList<MemberBean>();
		getcon();
		try {
			String sql="select id from member";
			
			pstmt=con.prepareStatement(sql);

			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				MemberBean mem =new MemberBean();
				mem.setId(rs.getString(1));
				
				a.add(mem);
			}
			
		}catch(Exception e) {
			
		}
		return a;
	}
	
	//우편번호를 매게변수로하여 그 우편번호에 해당하는 상세한 주소들을 반환함
	public Vector<ZipBean> zipsearch(String zipcode){
		Vector<ZipBean> v = new Vector<ZipBean>();
		getcon();
		
		try {
			String sql="select * from tblZipcode where zipcode=?";
			
			pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, zipcode);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				ZipBean zip = new ZipBean();
				
				zip.setArea1(rs.getString(2));
				zip.setArea2(rs.getString(3));
				zip.setArea3(rs.getString(4));
				
				v.add(zip);
			}
			
		}catch(Exception e) {
			
		}
		return v;
	}
	
	
	
}
