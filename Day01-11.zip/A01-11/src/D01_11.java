import java.util.*;
public class D01_11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*System.out.println("�� �Է�");
		int n= sc.nextInt();
		
		if(n<0) {
			System.out.println("�Է��� ���� - �Դϴ�");
		}else {
			System.out.println("�Է��� ���� + �Դϴ�");
		}*/
		
		/*int i,k;
		
		for(i=1; i<=9; i++) {
			for(k=9;k>=2;k--) {
				System.out.printf("%3dX%2d=%d",k,i,k*i);
			}
			System.out.println("\n");
		}*/
		

		/*int i=0;
		while(i<=10) {
			if(i%2==0) {
				System.out.println(i);
			}
			i++;
		}*/
		
		/*int a=sc.nextInt();
		
		switch(a) {
		case 2 :
			for(int j=1; j<=9; j++) {
				System.out.printf("%dX%d=%d\n",a,j,a*j);
			}
				break;
		case 3 :
			for(int j=1; j<=9; j++) {
				System.out.printf("%dX%d=%d\n",a,j,a*j);
			}
				break;
		default :
			System.out.println("NONE");
			break;
		}*/
		
		/*int i=1;
		int hap=0;
		
		while(i<=100) {
			hap+=i;
			i++;
		}
		System.out.println(hap);
		*/
		
		
		/*while(true) {
			 int n=(int)(Math.random()*6)+1;
			 System.out.println(n);
			 if(n==6) {
				 break;
			 }
		}*/


		
		
		
	}

}
