import java.util.*;
public class D01_12 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		/*for(int i=5; i<=9; i++) {
			for(int j=1; j<=9; j++) {
				System.out.printf("%d X %d = %d\n",i,j,i*j);
			}
		}
		
		int a=1;
		int hap=0;
		while(a<101) {
			if(a%5==0) {
				hap+=a;
			}
			a++;
		}
		System.out.println(hap);*/
		
		
		while(true) {
			int x=(int)(Math.random()*5)+1;
			int y=(int)(Math.random()*5)+1;
			if(x+y==5) {
				break;
			}else {
				System.out.println(x+y);
			}
		}

	}

}
