import java.awt.Color;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;

class Mouse extends MouseAdapter implements MouseMotionListener{


	public void mouseDragged(MouseEvent e) {
		Container c=(Container)e.getSource(); //�����Լ����� ���ϴ��� ���������Լ� getSource
		c.setBackground(Color.yellow);
		
	}

	
	public void mouseMoved(MouseEvent e) {

		
	}
	public void mouseReleased(MouseEvent e) {
		Container c=(Container)e.getSource();
		c.setBackground(Color.red);
		
	}

}
public class colorchange extends JFrame {
	colorchange(){
		Container c = getContentPane();
		c.setBackground(Color.red);
		
		c.addMouseMotionListener(new Mouse());
		c.addMouseListener(new Mouse());
		
		setSize(500,500);
		setVisible(true);
	}
	public static void main(String[] args) {
		new colorchange();
		

	}

}
