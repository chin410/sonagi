import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

class Text implements ActionListener{
	JTextField jid;
	JPasswordField jpw;
	Text(JTextField jid,JPasswordField jpw){
		this.jid=jid;
		this.jpw=jpw;
	}
	public void actionPerformed(ActionEvent e) {
		System.out.println(jid.getText());
		System.out.println(jpw.getText());
	}
	
}
public class list_combobox {
	static class GUI extends JFrame{
	GUI(){
		setBounds(120,120,150,150); //������
		
		setLayout(new FlowLayout());
		
		JLabel id = new JLabel("ID",SwingConstants.LEFT);
		JTextField jid = new JTextField(20);
		
		JLabel pw = new JLabel("PW",SwingConstants.LEFT);
		JPasswordField jpw = new JPasswordField(20); //��й�ȣ �Է�â
		jpw.setEchoChar('*'); //�� ���ڿ��� �Ⱥ��̰�
		
		jpw.addActionListener(new Text(jid,jpw));
		
		
		this.add(id);
		this.add(jid);
		this.add(pw);
		this.add(jpw);
				
		
		setVisible(true);
	}
	}

	public static void main(String[] args) {
		new GUI();

	}

}
