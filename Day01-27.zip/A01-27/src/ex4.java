import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class ex4 extends JFrame{
	ex4(){

		  

		  JCheckBox j=new JCheckBox("�ڹ�");

		  this.setLayout(new FlowLayout());

		  

		  j.addItemListener(new ItemListener() {

		   public void itemStateChanged(ItemEvent e) {

		    if(e.getStateChange()==ItemEvent.SELECTED) {

		     System.out.println("�ڹ� ��մ�");

		    }

		   }

		  });

		  

		  this.add(j);

		  setVisible(true);

		 }

	public static void main(String[] args) {
		new ex4();

	}

}
