import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class RadioButton extends JFrame{
	 JRadioButton j1=new JRadioButton("¥���");

	 JRadioButton j2=new JRadioButton("������");

	 RadioButton(){

	  

	  Container c=getContentPane();

	  c.add(j1);

	  c.add(j2);

	  c.setLayout(new FlowLayout());

	  

	  ButtonGroup b1=new ButtonGroup();

	  b1.add(j1);

	  b1.add(j2);

	  

	  A a=new A();

	  j1.addItemListener(a);

	  j2.addItemListener(a);

	 
	  setSize(500,500);
	  setVisible(true);

	  //������ư �����۸�����
	  /*j1.addItemListener(new ItemListener() {
		
		@Override
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange()==ItemEvent.SELECTED) {
				System.out.println("¥���");
			}
			
		}
	} );*/
	  
	 }
	 
	 class A implements ItemListener{

		  public void itemStateChanged(ItemEvent e) {

		   if(e.getStateChange()!=ItemEvent.SELECTED) {

		    return;

		   }

		   if(e.getItem()==j1) {

		    System.out.println("¥���");

		   }

		   else if(e.getItem()==j2) {

		    getContentPane().setBackground(Color.pink);

		   }

		  }

		 }
	public static void main(String[] args) {
		new RadioButton();

	}

}
