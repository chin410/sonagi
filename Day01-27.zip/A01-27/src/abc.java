import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

class ac extends MouseAdapter{
	public void mouseClicked(MouseEvent e) {
		JButton b1 =(JButton)e.getSource();
		if(b1.getText().equals("ok")) {
			System.out.println("ok");
		}
		else {
			b1.setEnabled(false);
		}
	}
}


public class abc extends JFrame{
	abc(){
		Container c = getContentPane();
		JButton b1 = new JButton("ok");
		JButton b2 = new JButton("cancel");
		
		b1.addActionListener(new ActionListener() {			
		
			public void actionPerformed(ActionEvent e) {
				System.out.println("ok");
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				b1.setEnabled(false);
				
			}
		});
		
		b1.addMouseListener(new ac());
		b2.addMouseListener(new ac());
		
		c.setLayout(new FlowLayout());
		
		c.add(b1);
		c.add(b2);
		
		setSize(500,500);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new abc();

	}

}
