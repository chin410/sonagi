import java.awt.Button;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


class My implements ActionListener{

	public void actionPerformed(ActionEvent e) {
		JButton b1=(JButton)e.getSource(); //�̺�Ʈ�� ��� �Ͼ���� �˾Ƴ�
		if(b1.getText().equals("����")) {
			b1.setText("execute");
		}else {
			b1.setText("exe");
		}
	}
	
}
public class listener extends JFrame {
	 listener() {
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		
		JButton b1 = new JButton("����");
		b1.addActionListener(new My());
		c.add(b1);
		
		setSize(300,300);
		setVisible(true);
	}

	public static void main(String[] args) {
		new listener();


	}

}
