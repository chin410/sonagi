import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;
class Person1 implements Serializable{
	String a,b;
	int c,d;
	Person1(String a,String b,int c,int d){
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
	}
	void show() {
	System.out.println(a+" "+" "+b+" "+c+" "+d);	
	}
}


class Circle{

   private double x,y;

   private int r;

   Circle(double x, double y, int r){

          this.x=x;  this.y=y; this.r=r; }

   void show(){

     System.out.println(x + " " +y + " " +r);}}

interface Person{

    String work();
    }



class Worker implements Person{
	String a;

	
	public String work() {
		a="���Ѵ�";
;		return a;
	}
	
 static void pr(Person p){

    System.out.println(p.work()); 
    
 }

}

class Student implements Person{
	String a;
	
	public String work() {
		a="�����Ѵ�";
		return a;
	}
	
 static void pr(Person p){

    System.out.println(p.work()); 
    
 }

}

 
 
 
 
public class ex2 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		FileOutputStream fos = new FileOutputStream("t.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);	
		
	      FileInputStream fis = new FileInputStream("t.txt");
	      ObjectInputStream ois = new ObjectInputStream(fis);
	      
		
         Person1 p=new Person1("Jack", "computer", 20, 123); 

             p.show();   //������ �� ����ϴ� �Լ�
             
             Circle c []=new Circle[3];
             
            /* for(int i=0; i<c.length; i++) {
            	 double a=sc.nextDouble();
            	 double a1=sc.nextDouble();
            	 int a2=sc.nextInt();
            	 c[i]= new Circle(a,a1,a2);
            	 c[i].show();
             }*/
             
             Worker w=new Worker();
             
             w.pr(new Worker());  

             w.pr(new Student());

  

	}



}
