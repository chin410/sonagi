import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class img extends JFrame {
	img(){
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		
		JLabel j =new JLabel("�ȳ�");
		
		ImageIcon i =new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/aaa.jpg");
		
		JLabel j1 =new JLabel(i);
		JLabel j2 =new JLabel("�˹ٰ���ȴ�",SwingConstants.CENTER);
		
		c.add(j);
		c.add(j1);
		c.add(j2);
		setSize(500,500);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new img();

	}

}
