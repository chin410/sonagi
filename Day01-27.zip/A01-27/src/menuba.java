import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class menuba extends JFrame{
	menuba(){
		JMenuBar j = new JMenuBar();
		JMenu j1 = new JMenu("Fire");
		JMenu j2 = new JMenu("In");
		JMenu j3 = new JMenu("The Hole");
		
		JMenuItem j4 = new JMenuItem("New");
		JMenuItem j5 = new JMenuItem("World");
		
		setJMenuBar(j);
		j.add(j1);
		j.add(j2);
		j.add(j3);
		j.add(j4);
		j.add(j5);
		
		setSize(500,500);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new menuba();

	}

}
