import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

/*class ad implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		Container c =(Container)e.getSource();
		JButton b1 =(JButton)e.getSource();
		JButton b2 =(JButton)e.getSource();
		JButton b3 =(JButton)e.getSource();
		
		if(b1.getText().equals("Ok")) {
			c.setBackground(Color.orange);
		}else if(b2.getText().equals("Cancel")) {
			b1.setEnabled(false);
		}else {
			//system.out.println(e.getX+" "+e.getY());
		}
	}
}*/
public class ex extends JFrame{
	ex(){
		Container c = getContentPane();
		
		c.setLayout(new FlowLayout());
		c.setBackground(Color.blue);
		
		JButton b1= new JButton("Ok");
		JButton b2= new JButton("Cancel");
		JButton b3= new JButton("Get");
		
		c.add(b1);
		c.add(b2);
		c.add(b3);
		
		/*b1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
					c.setBackground(Color.orange);
			}
		});
		b2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
					b1.setEnabled(false);
			}
		});
		b3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				System.out.println(e.getX()+" "+e.getY());
			}
		});*/

		
		
		setSize(500,500);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		Boolean b1 = false;
		b1.toString();
		
		double d1=Double.parseDouble("36.5");
		int i1 =Integer.parseInt("35");
		
		new ex();
		
		
		
		
	}

}
