import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class List_ComboBox0000 extends JFrame{
	List_ComboBox0000(){
		String str []= {"�Ƹ�","�ֿ���"};
		ImageIcon im[]= {new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/abc.jpg"),
		                 new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/aaa.jpg")};
		JLabel j = new JLabel(im[0]);
		
		Container c =getContentPane();
		c.setLayout(new FlowLayout());
		
		JComboBox jc = new JComboBox(str);
		
		
		c.add(jc);
		c.add(j);
		
		jc.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int i=jc.getSelectedIndex(); //�޺��ڽ��� ���õ� �̹����� �ε��� �˾Ƴ���
				j.setIcon(im[i]);
				
			}
		});
		
		setSize(500,500);
		setVisible(true);
		
	}
	public static void main(String[] args) {
		new List_ComboBox0000();
		

	}

}
