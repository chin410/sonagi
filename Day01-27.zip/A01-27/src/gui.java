import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


/*class Mouse implements MouseListener{ //���콺 �����ʾ��� �Լ�5���ٽ����

	
	public void mouseClicked(MouseEvent e) {//Ŭ������ ��
		System.out.println("���콺 Ŭ��");
	
		
	}

	
	public void mousePressed(MouseEvent e) {
		
		
	}

	
	public void mouseReleased(MouseEvent e) {
		
		
	}

	
	public void mouseEntered(MouseEvent e) {
		
		
	}

	
	public void mouseExited(MouseEvent e) {
		
		
	}

}*/

/*class Mouse extends MouseAdapter{ ���콺 ��;��� �ʿ��� ���콺 �Լ��� ��밡��
	public void mouseClicked(MouseEvent e) {
		System.out.println("���콺 Ŭ��");
	}
}*/

/*class Mouse implements MouseMotionListener{


	public void mouseDragged(MouseEvent e) {
		System.out.println(e.getX()+" "+e.getY());
		
	}


	public void mouseMoved(MouseEvent e) {
		System.out.println(e.getX()+" "+e.getY());
		
	}
	
}*/

public class gui {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setLayout(new FlowLayout());
		
		
		JButton j1 = new JButton("��");
		JButton j2 = new JButton("��");
		
		j1.addMouseMotionListener(new Mouse());
		j2.addMouseMotionListener(new Mouse());
		
		f.add(j1);
		f.add(j2);
		f.setVisible(true);
		
		f.setSize(300,300);
	}

}
