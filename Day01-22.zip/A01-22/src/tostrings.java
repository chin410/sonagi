class In{
	private int a;
	In(int a){
	this.a=a;
	}
	public String toString() { //public ���
		return a+" ";
	}
}
public class tostrings {

	public static void main(String[] args) {
		In i = new In(4);
		System.out.println(i);

	}

}
