interface Addin{
	public int add(int a,int b);
	public int add(int a);
}
class Add implements Addin{
	public int add(int a,int b) {
		return a+b;
	}
	public int add(int a) {
		int n=0;
		for(int i=1; i<=a; i++) {
			n+=i;
		}
		return n;
	}
}
public class ex {

	public static void main(String[] args) {
		/*Add a = new Add();
		System.out.println(a.add(1,4));
		
		System.out.println(a.add(10));*/
		
		

	}

}
