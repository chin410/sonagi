class Tv{
	public void on() {
		System.out.println("Ƽ�� ��");
	}
}
interface Computer{
	public void m();
}
class Com{
	public void m() {
		System.out.println("��");
	}
}
class Ipad extends Tv implements Computer{
	Com c = new Com();
	public void m() {
		c.m();
	}
	
	public void ip() {
		m();
		on();
	}
	
}

interface Food{
	String name();
	
	static void pr(Food f) {
		System.out.println(f.name());
	}
	
}

class Pizza implements Food{
	public String name() {
		return "����";
	}
	
}

class Steak implements Food{
	public String name() {
		return "����Ű";
	}
}



interface IT{
	public void java();
}

class Student2{

	public void study(IT i) {
		i.java();
	}
}

class ITStudent implements IT{
	public void java() {
		System.out.println("�ڹٰ���");
	}
}

class DBStudent implements IT{
	public void java() {
		System.out.println("DB����");
	}

}

public class interface3 {
	static void pr(Food f) {
		System.out.println(f.name());
	}

	public static void main(String[] args) {
		Ipad i = new Ipad();
		i.ip();
		
		pr(new Pizza());
		pr(new Steak());
		
		Student2 s = new Student2();
		ITStudent i1 = new ITStudent();
		DBStudent d = new DBStudent();
		
		s.study(i1);
		s.study(d);
		
		
		
		

	}

}
