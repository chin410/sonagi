class Person{

}
class Student extends Person{}
class Worker extends Person{}
class ITWorker extends Person{}

public class instanceof1 {
	
	static void show(Person p) {
		if(p instanceof Person) {
			System.out.println("���");
		}
		if(p instanceof Student) {
			System.out.println("�л�");
		}
		if(p instanceof Worker) {
			System.out.println("���ѷ�Ż����");
		}
		if(p instanceof ITWorker) {
			System.out.println("IT���ѷ�Ż����");
		}
	}

	public static void main(String[] args) {

		show(new Student());
		show(new Worker());
		show(new ITWorker());
	}

}
