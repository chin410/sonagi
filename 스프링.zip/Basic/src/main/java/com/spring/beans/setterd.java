package com.spring.beans;

public class setterd {
	public setterd() {
		System.out.println("생승자");
	}
}
