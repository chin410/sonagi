package com.spring.beans;

public class bean {
	private String d3;
	private int d4;
	private Data d1;
	private Data d2;
	
	public bean(int d4,String d3) {
		this.d4=d4;
		this.d3=d3;
		System.out.println("생성자");
	}


	
	
	
}
