package com.spring.beans;

public class setterb {
	private int d1;
	private double d2;
	private boolean d3;
	private String d4;
	private setterd d5;
	private setterd d6;
	
	public int getD1() {
		return d1;
	}
	public void setD1(int d1) {
		this.d1 = d1;
	}
	public double getD2() {
		return d2;
	}
	public void setD2(double d2) {
		this.d2 = d2;
	}
	public boolean getD3() {
		return d3;
	}
	public void setD3(boolean d3) {
		this.d3 = d3;
	}
	public String getD4() {
		return d4;
	}
	public void setD4(String d4) {
		this.d4 = d4;
	}
	public setterd getD5() {
		return d5;
	}
	public void setD5(setterd d5) {
		this.d5 = d5;
	}
	public setterd getD6() {
		return d6;
	}
	public void setD6(setterd d6) {
		this.d6 = d6;
	}
}
