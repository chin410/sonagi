package com.spring.beans;

public class bean1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
