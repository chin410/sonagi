package com.spring.beans;

public class Data {
	
	public Data() {
		System.out.println("Data 생성자");
	}
	
}
