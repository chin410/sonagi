package com.spring.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.beans.setterb;

public class setterMainClass {

	public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/config/setterx.xml");
	
	setterb b1=(setterb)ctx.getBean("b1");
	 System.out.println(b1.getD1());
	 System.out.println(b1.getD2());
	 System.out.println(b1.getD3());
	 System.out.println(b1.getD4());
	 System.out.println("===================================");
	 b1.setD1(777);
	 System.out.println(b1.getD1());
	 
	
	}

}
