package com.spring.main;


import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.beans.CollecB;
import com.spring.beans.Data;
import com.spring.beans.bean;

public class CollecMain {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/config/CollecX.xml");
		
		CollecB b1 = ctx.getBean("b1", CollecB.class);
		Map<String, Object> m1=b1.getM1();
		

		System.out.println(m1.get("a"));
		System.out.println(m1.get("b"));
		System.out.println(m1.get("c"));
		System.out.println(m1.get("d"));
		System.out.println(m1.get("e"));
		List<String> e=(List<String>)m1.get("e");
		for (String str : e) {
			System.out.println(str);
		}
		
		

		
		
		

		


	}

}
