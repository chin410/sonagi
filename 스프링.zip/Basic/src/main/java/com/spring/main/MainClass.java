package com.spring.main;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.beans.Data;
import com.spring.beans.bean;
import com.spring.beans.setterb;


public class MainClass {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/config/bean.xml");

		bean b1 = ctx.getBean("b1",bean.class);
		System.out.println(b1);
		


	}

}
