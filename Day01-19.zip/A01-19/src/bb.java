import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class bb {

	public static void main(String[] args) throws IOException {
		
	   /*byte b[]={4,6,7,8,-1,24};
	   
	   FileOutputStream out = new FileOutputStream("aa.txt");
	   
	   for(int i=0; i<b.length; i++) {
		   out.write(b[i]);
	   }
	   out.close();
	   
	   FileInputStream in = new FileInputStream("aa.txt");
	   
	   int str;
	   int j=0;
	   byte str1[]=new byte[10];
	   
	   while((str=in.read())!=-1) {
		   str1[j]=(byte)str;
		   System.out.print(str1[j]);
		   j++;
	   }in.close();*/
		
		FileWriter fw = new FileWriter("ab.txt");
		BufferedWriter bf= new BufferedWriter(fw);
		
		bf.write("���� �ڹٸ� �����մϴ�.");
		bf.close();
		
		FileReader fr = new FileReader("ab.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String str;
		String str1[]=new String[10];
		int ch=0;
		while((str=br.readLine())!=null) {
			str1[ch]=str;
			ch++;
			System.out.println(str1[0]);
			System.out.println(str);
		}
		
		
	   
	   

	}

}
