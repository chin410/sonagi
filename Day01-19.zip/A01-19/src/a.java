import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class a {

	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("a.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("�ȳ��ϼ��� �ݰ����ϴ�");
		bw.close();
		
		FileReader fr = new FileReader("a.txt");
		BufferedReader br = new BufferedReader(fr);
		
		/*String n;
		while(true) {
			n=br.readLine();
			if(n==null) {
				break;
			}
			System.out.println(n);
		}*/
		
		String str;
		String str1[] = new String[10];
		int i=0;
		while((str=br.readLine())!=null) {
			str1[i]=str;
			i++;
		}
		System.out.println(str1[0]);
		
		
		

	}

}
