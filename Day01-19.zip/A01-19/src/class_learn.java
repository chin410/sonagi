import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class class_learn {
	
	static int same(int a[], int b[]) {
		int n=0;
		for(int i=0; i<a.length; i++) {
			for(int j=0; j<b.length; j++) {
				if(a[i]==b[j]) {
					n++;
				}	
			}
		}
		return n;
	}
	
	static void show(int a[]) {
		int b[] = new int [5];
		int n=0;
		for(int i=4; i>=0; i--) {
			b[0+n]=a[i];
			n++;
		}
		for(int i=0; i<b.length; i++) {
		System.out.printf("%d ",b[i]);
		}
				
	}
	
	

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);		
		byte b []=new byte[] {4,6,7,8,-1,24};
		
		FileOutputStream out = new FileOutputStream("test.txt");
		//1��
		
		//����
		
		for(int i=0; i<b.length; i++) {
			out.write(b[i]); //����Ʈ�迭
		}
		out.close();
		
		//���
		FileInputStream in = new FileInputStream("test.txt");
		int ch;
		int rr=0;
		byte bt[]=new byte[6];
		
		while((ch=in.read())!=-1) { //-1=������ ��
			bt[rr]=(byte)ch;
			System.out.printf("%d ",bt[rr]);
			rr++;
		}
		System.out.println();
		
		
	
	   
	   //2��
	   int lottop[]={4,10,25,30,45,47};
	   int my[]={1,4,7,26,45,48};
	   int r;

	   r=same(lottop,my);
	   System.out.printf("��ġ�ϴ� ��ȣ�� ����:%d\n", r);
	   
	   //4��
	   int ary[]={6,2,8,4,9};
	   show(ary);
	   
	   //5��
	   int [][]aryy ={{43,97},{34,77,87},{100,95,38,89}};
	   int sum=0;
	   for(int i=0; i<aryy.length; i++) {
		   for(int j=0; j<aryy[i].length; j++) {
			   sum+=aryy[i][j];
		   }
	   }
	   System.out.println(sum);
	   System.out.printf("%.1f\n",(double)sum/9);
	   
	   
	   //6��
	  /* int ary1[]= new int[5];
	   int max=0;
	   int min=9999;
	   for(int i=0; i<ary1.length; i++) {
		   System.out.println("���� �Է� 5��");
		   ary1[i]=sc.nextInt();
		   if(ary1[i]>max) {
			   max=ary1[i];
		   }
		   if(ary1[i]<min) {
			   min=ary1[i];
		   }
	   }

	   for(int i=0; i<ary1.length; i++) {
		   if(ary1[i]==max) {
			   ary1[i]=0;
		   }
		   if(ary1[i]==min) {
			   ary1[i]=0;
		   }
	   }
	   int hap=0;
	   System.out.print("��ȿ����:");
	   for(int i=0; i<ary1.length; i++) {
		   if(ary1[i]!=0) {
		   System.out.printf("%d ",ary1[i]);
		   }		   
		   hap+=ary1[i];
	   }
	   System.out.printf("���:%.1f",hap/3.0);
	   */
	   FileWriter fw=new FileWriter("Sampel.txt"); //���ϻ���
	   BufferedWriter out1=new BufferedWriter(fw);
		
		out1.write("���� �ڹٸ� �����մϴ�"); //���Ͽ� ����
		out1.close();
		
		FileReader fr = new FileReader("Sampel.txt");//���� �б�
		BufferedReader br = new BufferedReader(fr);
		
		String str=null;
		String str2[]=new String[10];
		int i=0;
		while((str=br.readLine())!=null) { //�о�ʰ� �迭������
			str2[i]=str;
			i++;
			}
		
			for (String str3:str2) {  //for each��
			if (str3==null) {
			break;
			}
			
			System.out.print(str3+" ");
			System.out.print(str2[0]+" ");
			}
			br.close();
			fr.close();

		
	     /*while(true) {
	    	 str=br.readLine();    //�о�°� ��Ʈ���� ����
	    	 if(str==null) {
	    		 break;
	    	 }    	
	    	System.out.println(str);
	     }*/
	     
	     

	     
	     
	     br.close();
	     fr.close();
	   
	   
	   
	   
	   


		
		

	}

}
