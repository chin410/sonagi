import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Day01_19 {

	public static void main(String[] args) throws IOException {
		
		FileWriter fw = new FileWriter("i.txt");
		BufferedWriter wr = new BufferedWriter(fw);
		
		wr.write("������ ȭ����");
		wr.newLine();
		wr.write("�ڹٴ� �� ��ճ׿�");                   //����
		wr.close();
		
		FileReader fr = new FileReader("i.txt");
	    BufferedReader br = new BufferedReader(fr);
	    
	    
	    while(true) {
	    	String str=br.readLine(); //readLine(),���ڿ��� ��κ� null��
	    	if(str==null) {                         //���
	    		break;
	    	}
	    	System.out.println(str);
	    }br.close();
		
		FileInputStream fi = new FileInputStream("i.txt");
		byte [] bt = new byte[1024];
		
		int ch=-1; //�������� ��κ� -1��
		int i=0;
		while((ch=fi.read())!=-1) { //read() -1��
			bt[i]=(byte)ch;
			i++;
		}
		System.out.println(new String(bt));

	}

}
