import java.awt.FlowLayout;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFrame;

class My{
	String name;
	int id;
	
	My(String a, int b){
		name=a;
		id=b;
	}
	public String toString() {
		return name+" "+id;
		
	}
}
public class vectorr {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setLayout(new FlowLayout());
		
		Vector<My> v = new Vector<My>();
		v.add(new My("�ο�",1));
		v.add(new My("�Ƹ�",2));
		v.add(new My("�Ƹ�",3));
		
		JComboBox jc = new JComboBox(v);
		f.add(jc);
		f.setVisible(true);
		f.setSize(300,300);
	}

}
