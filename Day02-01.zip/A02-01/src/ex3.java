import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JFrame;

public class ex3 extends JFrame{
	ex3(){

Color cc[]={Color.RED, Color.orange, Color.yellow, Color.GREEN, Color.BLUE};
		Container c = getContentPane();
		
		c.setLayout(new GridLayout(1,5));
		
		JButton b[]=new JButton[5];
		
		for(int i=0; i<b.length; i++) {
			b[i]=new JButton();
			b[i].setBackground(cc[i]);
		}
		for(int i=0; i<b.length; i++) {
			c.add(b[i]);
		}
		
		setSize(500,500);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new ex3();
		
		ArrayList<Integer> arr= new ArrayList<Integer>();
		for(int i=0; i<10; i++) {
			arr.add((int)(Math.random()*100)+1);
		}
		Iterator<Integer> it = arr.iterator();
		
		while(it.hasNext()) {
			int a=it.next();
			System.out.println(a);
		}

	}

}
