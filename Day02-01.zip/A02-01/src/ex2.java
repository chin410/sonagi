import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JTextField;
class Profile{
  String name,id;
  Profile(String name, String id){
    this.name=name; this.id=id;
  }
  String getname(){ return name;}
  String getid(){ return id;}

}
public class ex2 {


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�ο��� ����");
		int a=sc.nextInt();
		Profile p[]=new Profile[a];
		
		for(int i=0; i<p.length; i++) {
			System.out.println("�̸�,id");
			String na=sc.next();
			String id=sc.next(); 
			p[i]=new Profile(na,id);
		}
		for(int i=0; i<p.length; i++) {
			System.out.println(p[i].getname()+" "+p[i].getid());
		}
		
		   JFrame j = new JFrame();
		   JTextField j1 = new JTextField(10);
		   j.setLayout(new FlowLayout());
		    j.add(j1);
			
			j1.addKeyListener(new KeyAdapter() {
				public void keyReleased(KeyEvent e) {
					int key=e.getKeyCode();
					
					if(key==KeyEvent.VK_ENTER) {
						j1.setText(p[0].getname()+" "+p[0].getid());
						
					}
				}
			});
			j.setSize(300,300);
			j.setVisible(true);


		}

}
