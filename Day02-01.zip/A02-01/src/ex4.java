import java.awt.Container;
import java.awt.FlowLayout;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JLabel;

class Th extends Thread{
	JLabel a;
	Th(JLabel a){
		this.a=a;
	}
	public void run() {
		try {

      for(int i=0; i<10; i++) {
			a.setText(Integer.toString(i));
			Thread.sleep(1000);
		}
		}catch(Exception e) {}
		
	}
}
public class ex4 extends JFrame{
	ex4(){
	   Container c=getContentPane();
	   c.setLayout(new FlowLayout());
       JLabel j=new JLabel();
       c.add(j);

   

       Th t=new Th(j); //������ ��ü ����
       setSize(300,300);
       setVisible(true);
       t.start();               //������ ����
}
	


	public static void main(String[] args) {
		new ex4();
		Scanner sc = new Scanner(System.in);
		
		HashMap<Integer, String> a = new HashMap<Integer, String>();
		
		a.put(25, "�̿�");
		a.put(24, "�ο�");
		a.put(23, "�Ƹ�");
		
		Set<Integer> key=a.keySet();
		Iterator<Integer> it=key.iterator();
		
		while(it.hasNext()) {
			System.out.println("�����Է�");
			int n=sc.nextInt();
			int kk=it.next();
			if(n==kk) {
				System.out.println(kk+" "+a.get(kk));
			}
		}

	}

}
