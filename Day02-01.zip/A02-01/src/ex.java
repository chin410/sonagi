import java.util.*;
class Rectangle{
	private int width;
	private int height;
	void show(int width,int height) {
		int re=width*height;
		System.out.printf("���̴�: "+width*height);
	}
}

public class ex {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true) {
		try {
			System.out.println("�ʺ� ���� �Է�");
			int width=sc.nextInt();
			int height= sc.nextInt();
			Rectangle r = new Rectangle();
			r.show(width,height);
			break;
		}catch(InputMismatchException e) {
			System.out.println("�ٽ��Է��϶�");
			sc.nextLine();
			continue;
			
		}
		
		}
	}

}
