import java.util.ArrayList;
import java.util.Iterator;


//linkedlist
class Box<T>{
	T t;
	Box<T> next;
	
	void in(T t) {
		this.t=t;
	}
	T out() {
		return t;
	}
}
class Profile1{
	String id;
	int age;
	Profile1(String a,int b){
		id=a;
		age=b;
	}
}

public class collection {

	public static void main(String[] args) {
	   ArrayList<String> a = new ArrayList<>();
	   a.add("bb");
	   a.add("cc");
	   a.add("dd");
	   Iterator<String> it = a.iterator();
	   while(it.hasNext()) {
		   String n =it.next();
		   System.out.println(n);
	   }
	 ArrayList<Profile1> arr=new ArrayList<>(); // <>�� Ŭ���� �ֱ� ����
		
		arr.add(new Profile1("aa",12)); //���ʴ�� �ε��� 0,1,2
		arr.add(new Profile1("�Ф�",14));
		arr.add(new Profile1("cc",15));
		
		for(int i=0; i<arr.size(); i++) {
			Profile1 p = arr.get(i);
		System.out.println(p.age+" "+p.id);
		}
		
		//linkedlist
		Box<Integer> b = new Box<>();
		
		  b.in(30);

		  b.next=new Box<Integer>();
		  b.next.in(40); //��ü�� �ѹ� �� ����
		
		  b.next.next=new Box<Integer>();
		  b.next.next.in(50);   

		  Box<Integer> tmp;

		  tmp=b.next;

		  System.out.println(tmp.out());
		

	}

}
