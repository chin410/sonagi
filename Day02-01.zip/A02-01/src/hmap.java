import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class hmap {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashMap<String,Integer> h = new HashMap<>();
		
		for(int i=0; i<3; i++) {
			System.out.println("����");
			h.put(sc.next(), sc.nextInt());
		}
		
		Set<String> key=h.keySet();
		Iterator<String> it=key.iterator();
		
		int max=0;
		String str="";
		
		while(it.hasNext()) {
			String name=it.next();
			int age=h.get(name);
			
			if(max<age) {
				max=age;
				str=name;
			}
		}
		System.out.println(max+" "+str);
		
		
	}

}
