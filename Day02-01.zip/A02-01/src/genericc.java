class Food{

	void show() {
		System.out.println("����");
	}
}

class Pizza extends Food{
	
	void show() {
		super.show();
		System.out.println("����");
	}	
}

class Fo<T>{
	T t;
	void in(T t) {
		this.t=t;
	}
	T out() {
		return t;
	}
}
public class genericc {
	//���׸� Ŭ���� ����
	static void pr(Fo< ? extends Food>f){
		// Fo < ? extends Food>f = f
		Food fo=f.out();
		fo.show();
	}
	public static void main(String[] args) {
		Fo<Food> f = new Fo<Food>();
		f.in(new Food());
		pr(f);
		
		Fo<Pizza> f1 = new Fo<Pizza>();
		f1.in(new Pizza());
		pr(f1);

	}

}
