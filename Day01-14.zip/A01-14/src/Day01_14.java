import java.util.*;
public class Day01_14 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*System.out.println((int)(50+11.8));
		
		int n=0;
		while(true) {
			n++;
			if(n%3==0) {
				continue;
			}
			if(n>20) {
				break;
			}
			System.out.println(n);
		}*/
		
		//1��
		/*int ary1 []=new int[10];
		int hap=0;
		for(int i=0; i<ary1.length; i++) {
			System.out.println("���� �Է� 10��");
			ary1[i]=sc.nextInt();
			if(ary1[i]%7==0) {
				System.out.println(ary1[i]);
			}
			hap+=ary1[i];
		}
		System.out.println(hap/ary1.length);
		
		 //2��
		 double sum=0.0;

		 double ary[]={1.0, 1.5, 2.0, 2.5};
		 
		 int i=0;
		 
		 while(i<4) {
			sum+=ary[i];
			i++;
		 } 
		 System.out.println(sum);
		 
		  i=0;
		  sum=0;
		 do {
			sum+=ary[i];
			i++;
		 }while(i<4);
		 System.out.println(sum);
		 
		  i=0;
		  sum=0;
		 for(double a:ary) {
			sum+=a;
		 }
		 System.out.println(sum);*/
		
		
		int ary [][]=new int [] [] {{0,1,2},{3,4,5},{6,7,8}};
		String a [][] = new String [][] {{"a","b","c"},{"d","e","f"}};
		
		int sum=0;
		int aryy [][] =new int [3][4];
		for(int i=0; i<aryy.length; i++) {
			for(int j=0; j<aryy[i].length; j++) {
				aryy[i][j]=(int)(Math.random()*10);
				sum+=aryy[i][j];
				System.out.print(aryy[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("���� "+sum);
		 
		 
		 
		

	}

}
