package co.sp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import co.sp.beans.Databean;
@Controller
public class ControlTest {
	
@GetMapping(value = "java1")
public String java1(@ModelAttribute Databean db) {
	db.setId("chin410");
	db.setPw("1234");
	db.setAddr("서울");
	
	return "java1";
}

@GetMapping(value = "java2")
public String java2(@ModelAttribute ("me") Databean db) {
	db.setId("chin410");
	db.setPw("1234");
	db.setAddr("서울");
	
	return "java2";
}

@GetMapping(value = "java3")
public  String java3(Model mo) {
	Databean db = new Databean();
	db.setId("chin410");
	db.setPw("1234");
	db.setAddr("서울");
	
	mo.addAttribute("dd", db);
	
	return "java3";
	
}

}
