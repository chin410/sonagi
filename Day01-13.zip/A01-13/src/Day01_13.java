import java.util.*;
public class Day01_13 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// 1. �迭 ���� int a []=new int [10];
		// 2. �迭 �ʱ�ȭ int a [] = {1,2,3,4,5};
		// 3. �迭 �ʱ�ȭ +���� int a []=new int [] {1,2,3,4,5};
		
		/*double a[]=new double [5];
		int hap=0;
		System.out.println("�� �Է� (5)");
		for(int i=0; i<a.length; i++) {
			a[i]=sc.nextDouble();
			hap+=a[i];
		}
		System.out.println((double)hap/5);*/
		
		/*int a[]=new int[4];
		int hap=0;
		int X=1;
		for(int i=0; i<a.length; i++) {
			System.out.println(i+1+"��° ���ڸ� �Է��ϼ��� :");
			a[i]=sc.nextInt();
			hap+=a[i];
			X*=a[i];
		}
		System.out.println("�� ==>"+hap);
		System.out.println("�� ==>"+X);*/
		
		
	    /*//1��
	    int hap=0;
		for(int i=1;i<=10; i++) {
			hap+=i;
		}
		System.out.println(hap);
		
		//2��
		int a1;
		int b1=0;
		int hap1=0;
		while(true) {
			System.out.println("�����Է� 0 �Է½� ����");
			a1=sc.nextInt();
			if(a1==0) {
				break;
			}
			hap1+=a1;
			b1+=1;
		}
		System.out.println(hap1/b1);
		
		//3��
		int i=1;
		int sum=0;
	    while(i<10){
		i=i+2;
		sum +=i;
		}
		System.out.println(sum);
		
		while(true) {
			i=i+2;
			sum+=i;
			if(sum==35) {
				break;
			}
		}
		System.out.println(sum);
		
		  do {
			i+=2;
			sum+=i;
		}while(sum!=35);  
		  System.out.println(sum);
		  
		
		//4��	
		String a[]=new String [10];
		int b[]=new int[] {0,1,2,3,4};
		String c[]=new String[] {"java","c","c++"};
		int d[]=new int[9];
		*/
		
		/*for(int i=1; i<101; i++) {
			if(i%5==0 && i%10==0) {
				System.out.println(i);
			}
		}
		
		int i=1;
		while(i<101) {
			if(i%5==0 && i%10==0) {
				System.out.println(i);
			}
			i++;
		}
		
		int i1=0;
		do {
			i1++;
			if(i1%5==0 && i1%10==0) {
				System.out.println(i1);
				
			}
		}while(i1<101);*/
		
	/*int a[]= new int [5];
	int max=0;
	for(int i=0; i<a.length; i++) {
		a[i]=sc.nextInt();
		if(a[i]>max) {
			max=a[i];
		}
	}System.out.println(max);
		*/
		
		/*
		//for-each��
		String str[]= {"��ǻ��","�ڹ�","DB"};
		int ary[]= {1,2,3,4,5};
		for(int i:ary) {
			System.out.println(i);
		}
		
		for(String s:str) {
			System.out.println(s);
		}*/
		
		/*int ary [][]= new int[4][3];
		
		for(int i=0; i<4; i++) {
			for(int j=0; j<3; j++) {
				ary[i][j]=sc.nextInt();
				System.out.println(ary[i][j]);
			}
		}
		
		int ary1 [][]= new int[][] {
			{1,2,3,4},
		    {5,6,7,8}
			};
			
			for(int i=0; i<2; i++) {
				for(int j=0; j<4; j++) {
					System.out.println(ary1[i][j]);
				}
			}*/
		
		// ��=ary.length;
		// ��=ary[i].length;
		/*double ary [][] = new double[2][3];
		for(int i=0; i<ary.length; i++) {
			for(int j=0; j<ary[i].length; j++) {
				 ary[i][j]=sc.nextDouble();
				 System.out.println(ary[i][j]);
			}
		}
		
		int a[][]=new int [][] {{1,2},
                                {3,4},
                                {5,6}};*/
		
		/*int ary[][]=new int [2][3];
		int hap=0;
		for(int i=0; i<ary.length; i++) {
			for(int j=0; j<ary[i].length; j++) {
				ary[i][j]=sc.nextInt();
				hap+=ary[i][j];
			}
		}
		System.out.println(hap);*/
		
		/*String s [][] = {
				{"java"},
				{"C","C++"},
				{"HTML","CSS","PYTHON"}	};
		
		for(int i=0; i<s.length; i++) {
			for(int j=0; j<s[i].length; j++) {
				System.out.println(s[i][j]);
			}
		}*/
		
		/*int a [][]=new int [][] {{1,2,3,4,5},{6,7,8,9,10}};
		
		for(int i=0; i<a.length; i++) {
			for( int j=0; j<a[i].length; j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}*/
		
		/*String str="������ �����԰�,���� ���";
		
		String a[]=str.split(",");//���ڿ� �и�		
		for(String s:a) {
			System.out.println(s);
		}
		
		
		String a= str.substring(4,7);//���ڿ� ����
		System.out.println(a);
		
		String b=str.replace("������", "������");//���ڿ� ����
		System.out.println(b);*/
		
		  //String str="������ ������";
		  //String str1=str.concat("������ �����");
		  //���ڿ� ���� .concat();
		  //System.out.println(str1);
		
		String a="apple";
		String b="banana";
		
		if(a.compareTo(b)>0) {//a-b>0 == a>b
			System.out.println(a);
		}else if(a.compareTo(b)<0) {// a-b<0 == a<b
			System.out.println(b);
		}
		

		
		
		
		
		
		
		
		
	}

}
