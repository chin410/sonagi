package co.sp.controller;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import co.sp.beans.Databean;

@Controller
public class Control {
	
	@RequestMapping(value = "/")
	public String main() {
		return "start";
	}
	
	@RequestMapping(value = "java")
	public String java() {

		return "java";
	}
	
	@PostMapping(value = "result")
	public String res(@RequestParam(value = "id") String id,
			          @RequestParam String pw,
			          @RequestParam(value = "addr") String addr,
			          @ModelAttribute ("me") Databean db) {
		db.setId(id);
		db.setPw(pw);
		db.setAddr(addr);
		
		return "result";
	}
	

	
	
	
}
