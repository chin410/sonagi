package co.sp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import co.sp.beans.Data;

@Controller
public class Control2 {
	
	@GetMapping(value = "java4")
	public String str(Data d) {
		d.setDa1("인풋");
		d.setDa2("패스워드");
		d.setDa3("텍스트에리어");
		d.setDa4("히든");

		return "java4";
	}
	

	
}
