package co.sp.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.connector.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import co.sp.beans.Tdata;
import co.sp.beans.Tdata2;

@Controller
public class ControlTwo {
	@Autowired
	Tdata data1;
	
	@Resource(name = "r2")
	Tdata2 data2;
	
	@GetMapping(value = "/two/java1")
	public String da1(Model mo) {
		data1.setDa1("이녕");
		data1.setDa2("민주");
		
		data2.setDa3("유리");
		data2.setDa4("미연");
		
		System.out.println(data1.getDa1());
		System.out.println(data1.getDa2());
		System.out.println(data2.getDa3());
		System.out.println(data2.getDa4());
		
		mo.addAttribute("data1", data1);
		mo.addAttribute("data2", data2);
		
		
		return "forward:/two/result1";
	}
	
	@GetMapping(value = "/two/result1")
	public String re1() {
		
		return "/two/result1";
	}
	

	
	@GetMapping(value = "/two/result2")
	public String re2() {
		 
		return "/two/result2";
	}
	
	
	
}
