package co.sp.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import co.sp.beans.Data;

@Controller
public class Control2 {
	
	@RequestMapping(value = "/java1",method = RequestMethod.GET)
	public String ja1(Data d,Model m) {
		d.setS1("da3");
		d.setS2("da2");
		d.setS3("슬기");
		
		String ary[]= {"da1","da2","da3"};
		m.addAttribute("ary",ary);
		
		ArrayList<String> lis=new ArrayList<String>();
		lis.add("수지");
		lis.add("예리");
		lis.add("슬기");
		
		m.addAttribute("lis",lis);
		
		String [] chk= {"chk1","chk2"};	
		m.addAttribute("chk",chk);
		d.setS4(chk);
		d.setS5(chk);
		d.setS6(chk);
		
		d.setS7("태연");
		d.setS8("슬기");
		d.setS9("이린");
		
		return "java1";
	}
	
	@GetMapping(value = "java2")
	public String ja2() {
		return "redirect:/su1";
	}
	
	@GetMapping(value = "java3")
	public String ja3() {
		return "forward:/su2";
	}
	
	@RequestMapping(value = "su1")
	public String su1() {
		return "su1";
	}
	
	
	@RequestMapping(value = "su2")
	public String su2() {
		return "su2";
	}
	
	@RequestMapping(value = "/form")
	public String fo(@ModelAttribute("da") Data  d,Model m) {
		d.setS1("아이폰");
		String str1[]= {"아이폰","삼성","LG","그외"};
		m.addAttribute("str1", str1);
		
		d.setS2("남");
		String str2[]= {"남","여"};
		m.addAttribute("str2", str2);
		
		d.setS3("t1");
		String str[]= {"SKT","KT"};
		
		d.setS7("SKT");
		String str3[]= {"SKT","KT","LG","그외"};
		m.addAttribute("str3", str3);
		
		return "/form";
	}

}
