package co.sp.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.connector.Request;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestScope;
import org.springframework.web.servlet.ModelAndView;



import co.sp.beans.Odata;

@Controller
public class ControlOne {
	
	@RequestMapping("one/java1")
	public String ja1(HttpServletRequest req) {
		req.setAttribute("da1", "아린");
		
		return "forward:/one/result1";
		

	}
	
	@RequestMapping("one/result1")
	public String re1(HttpServletRequest req) {
		String da1=(String)req.getAttribute("da1");
		
		System.out.println(da1);
		return "one/result1";
		

	}
	
	@RequestMapping("one/java2")
	public String ja2(Model mo) {
		mo.addAttribute("da2","수진");
		
		return "forward:/one/result2";
		

	}
	
	@GetMapping("one/result2")
	public String re2(HttpServletRequest req) {
				
		System.out.println(req.getAttribute("da2"));
		return "one/result2";
	}
	
	@RequestMapping("one/java3")
	public ModelAndView ja3(ModelAndView m) {
		m.addObject("da3", "미연");
		m.setViewName("forward:/one/result3");
		
		return m;
		

	}
	
	@GetMapping("one/result3")
	public String re3(HttpServletRequest req) {
				
		System.out.println(req.getAttribute("da3"));
		return "one/result3";
	}
	
	@GetMapping(value = "/one/java4")
	public String ja4(Model mo) {
		Odata d = new Odata();
		d.setDa1("아린");
		d.setDa2("인영");
			
		mo.addAttribute("d", d);
		
		return "forward:/one/result4";
				
				
	}
	
	@GetMapping("one/result4")
	public String re4(HttpServletRequest req) {
		Odata d= (Odata)req.getAttribute("d");
		System.out.println(d.getDa1());
		System.out.println(d.getDa2());
		return "one/result4";
	}
	
}
