package co.sp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

import co.sp.beans.Tdata;
import co.sp.beans.Tdata2;


@Configuration
public class RootContext {
	
	@Bean
	@RequestScope //새로운 요청 발생했을 때 주입
	public Tdata data1() {
		return new Tdata();
	}
	
	@Bean("r2")
	@RequestScope
	public Tdata2 data2() {
		return new Tdata2();
	}
	

}
