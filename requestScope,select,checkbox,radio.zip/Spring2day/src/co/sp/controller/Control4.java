package co.sp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Control4 {
	
	@RequestMapping(value = "fo/java")
	public String java() {

		return "fo/java";
	}
	
	@RequestMapping(value = "fo/java2")
	public String java2(HttpServletRequest req) {
		req.setAttribute("da1", 10);
		req.setAttribute("da2", 20);
		return "fo/java2";
	}
	
	@RequestMapping(value = "fo/java3")
	public String java3(Model mo) {
	mo.addAttribute("da1", 20);
	mo.addAttribute("da2", 30);
		return "fo/java3";
	}
	
	@GetMapping(value = "fo/java4")
	public ModelAndView java4(ModelAndView m) {
		m.addObject("da1",50);
		m.addObject("da1",60);
		
		m.setViewName("java4");
		
		return m;
	}
}
