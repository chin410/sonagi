package co.sp.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import co.sp.beans.Data1;
import co.sp.beans.Data2;

@Controller
public class Control3 {
	
	@GetMapping(value = "thr/java") //url주소
	public String map(@RequestParam Map<String, String> m,
		              @RequestParam List<String> da3) {
		System.out.println(m.get("da1"));
		System.out.println(m.get("da2"));
		
		for(String str:da3) {
			System.out.println(str);
		}
		
		return "result";
	}
	
	@GetMapping("thr/java2")
	public String java(@ModelAttribute Data1 d1,
			           Data2 d2) {
		
		System.out.println(d1.getDa1());
		System.out.println(d1.getDa2());
		for(int i:d1.getDa3()) {
			System.out.println(i);
		}
		System.out.println(d2.getDa1());
		System.out.println(d2.getDa2());
		return "result";
	}
	
	

}
