package co.sp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("one")
public class Control2 {
	
	
	
	@RequestMapping(value = "/java",method = RequestMethod.GET)
	public String java() {
		return "one/java";
	}
	
	@RequestMapping(value = "/java2",method = RequestMethod.POST )
	public String java2() {
		return "one/java2";
	}
	
	
	@RequestMapping(value = "/java3",method = RequestMethod.POST )
	public String java3() {
		return "one/java3";
	}
	
	@RequestMapping(value = "/java3",method = RequestMethod.GET )
	public String java3_2() {
		return "one/java3";
	}
	//get,post 둘다주기 가능
	
	@GetMapping("/java4")
	public String java4() {
		return "one/java4";
	}
	
	@PostMapping("/java5")
	public String java5() {
		return "one/java5";
	}
	
	@GetMapping("/java6")
	public String java6() {
		return "one/java6";
	}
	
	@PostMapping("/java6")
	public String java6_2() {
		return "one/java6";
	}
	
	@RequestMapping(value = "java7",method = {RequestMethod.GET,RequestMethod.POST})
	public String java7() {
		return "one/java7";
	}
	
}
