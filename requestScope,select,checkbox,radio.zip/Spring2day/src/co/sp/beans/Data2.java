package co.sp.beans;

public class Data2 {
	private int da1;
	private int da2;
	private int da3[];
	
	
	public int getDa1() {
		return da1;
	}
	public void setDa1(int da1) {
		this.da1 = da1;
	}
	public int getDa2() {
		return da2;
	}
	public void setDa2(int da2) {
		this.da2 = da2;
	}
	public int[] getDa3() {
		return da3;
	}
	public void setDa3(int[] da3) {
		this.da3 = da3;
	}

}
