package co.sp.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.annotation.RequestScope;

import co.sp.beans.Data3;
import co.sp.beans.Data4;

@Controller
public class Control {
	@Autowired
	Data3 d3;
	
	@Resource(name = "DA")
	Data4 d4;
	
	@RequestMapping(value =  "/")
	public String root() {
		return "start";
	}
	
	@GetMapping(value = "java")
	public String ja1(Model mo) {
		d3.setDa1("D3/d1");
		d3.setDa2("D3/d2");
		d4.setDa1("D4/d1");
		d4.setDa2("D4/d2");
		
		System.out.println(d3.getDa1());
		System.out.println(d3.getDa2());
		System.out.println(d4.getDa1());
		System.out.println(d4.getDa2());
		
		mo.addAttribute("d3",d3);
		mo.addAttribute("d4",d4);
		
		
		
		return "forward:/result";
	}
	
	@RequestMapping(value =  "/result")
	public String res() {
		return "result";
	}
}
