package co.sp.config;

import javax.servlet.Filter;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class ConfigClass implements WebApplicationInitializer{//서블릿 컨텍스트 초기화

	@Override
	public void onStartup(ServletContext ser) throws ServletException {

		AnnotationConfigWebApplicationContext serv = new AnnotationConfigWebApplicationContext();//스프링 MVC 설정을 위한 클래스 객체 생성
		serv.register(ServletApp.class);
		
	
		DispatcherServlet dis = new DispatcherServlet(serv);//생성한 객체를 dispatcherServlet으로 등록
		ServletRegistration.Dynamic servlet = ser.addServlet("dispatcher", dis);
		
	
		servlet.setLoadOnStartup(1); //위의 서블릿을 가장 먼저 시작하는 서블릿으로지정
		servlet.addMapping("/"); // /주소에서 실행되게함
		
		//bean 지정 클래스 등록
		AnnotationConfigWebApplicationContext root = new AnnotationConfigWebApplicationContext();
		root.register(RootContext.class);
	
		ContextLoaderListener listener = new ContextLoaderListener(root);
		ser.addListener(listener);
		
		//파라미터 인코딩 필터
		FilterRegistration.Dynamic filter = ser.addFilter("encodingFilter", CharacterEncodingFilter.class);
		filter.setInitParameter("encoding", "UTF-8");
		filter.addMappingForServletNames(null, false, "dispatcher");
	
}

}

















