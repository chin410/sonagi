package co.sp.beans;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

@Component("DA")
@RequestScope
public class Data4 {
	
	private String da1;
	private String da2;
	public String getDa1() {
		return da1;
	}
	public void setDa1(String da1) {
		this.da1 = da1;
	}
	public String getDa2() {
		return da2;
	}
	public void setDa2(String da2) {
		this.da2 = da2;
	}
}
