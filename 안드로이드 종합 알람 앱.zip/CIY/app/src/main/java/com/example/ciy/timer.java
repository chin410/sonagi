package com.example.ciy;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Timer;
import java.util.TimerTask;

public class timer extends Activity {
    int timeTick=0; //시간을 임시로 저장하는 변수
    int minute=0; //분을 나타내는 변수
    int second=0; //초를 나타내는 변수
    MediaPlayer mediaPlayer;
    Handler myhandler = new Handler(Looper.getMainLooper());//핸들러생성


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timer);

        final TextView time = (TextView)findViewById(R.id.timertime);

        SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                timeTick=progress; //시크바에서 받아온 숫자 progress를 timeTick에 저장
                time.setText(Integer.toString(timeTick/60) + ":" + timeTick%60); //앞에는 분 뒤에는 초

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                timeTick = seekBar.getProgress();
                time.setText(Integer.toString(timeTick/60) + ":" + timeTick%60);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                timeTick = seekBar.getProgress();
                time.setText(Integer.toString(timeTick/60) + ":" + timeTick%60);
            }
        });

        final Button stop = (Button) findViewById(R.id.button3);
        Button start = (Button) findViewById(R.id.button2);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(timer.this,"타이머 시작",Toast.LENGTH_SHORT).show();
                minute = timeTick/60; //분을 나타냄
                second = timeTick%60; //초를 나타냄
                final TimerTask tt = new TimerTask() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                time.setText(Integer.toString(minute) + ":" + second);
                                //timer 안에선 텍스트뷰의 값을 수정할 수 없기 때문에 runOnUiThread함수 안에서 변경
                            }
                        });
                        if(second==0&&minute==0){
                            mediaPlayer = MediaPlayer.create(timer.this,R.raw.a2);//알람 경로 지정
                            mediaPlayer.start();//알람시작
                            myhandler.post(new Runnable() { //핸들러로 토스트 메시지를 감싸지 않으면 에러가 떠서 앱이 강제 종료됨
                                @Override
                                public void run() {
                                    Toast.makeText(timer.this,"타이머 종료",Toast.LENGTH_SHORT).show(); //타이머 종료를 알리는 토스트메세지
                                    cancel();
                                }
                            });
                        }

                        if (second==0){ //초가 0이되면 분을 하나 줄이고 초를 60초로만듬
                            minute--;
                            second=60;
                        }
                        second--; //타이머가 진행될때 마다 초를 -1함

                    }
                };
                Timer timer = new Timer();
                timer.schedule(tt,0,1000);// 처음에 딜레이를 1초두고 1초마다 TimerTask tt를 실행
                stop.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(timer.this,"타이머 정지",Toast.LENGTH_SHORT).show(); //타이머 정지를 알리는 토스트 메세지
                        tt.cancel();
                    }
                });

            }
        });


        Button btnAlarm = (Button) findViewById(R.id.btnalram);
        btnAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });

        Button btnStopWatch = (Button) findViewById(R.id.btnstopwatch);
        btnStopWatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),stopwatch.class);
                startActivity(intent);
            }
        });

        Button btntimer = (Button) findViewById(R.id.btntimer);
        btntimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),timer.class);
                startActivity(intent);
            }
        });

        Button btncalender = (Button) findViewById(R.id.btncalender);
        btncalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),calender.class);
                startActivity(intent);
            }
        });
    }
}
