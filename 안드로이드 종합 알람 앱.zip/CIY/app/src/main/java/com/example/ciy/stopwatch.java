package com.example.ciy;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;

import android.widget.TextView;


public class stopwatch extends Activity {

        TextView Output;
        TextView Rec;
        Button BtnStart;
        Button BtnRec;

        final static int Init =0;
        final static int Run =1;
        final static int Pause =2;

        int cur_Status = Init; //현재의 상태를 저장할변수를 초기화함.
        int Count=1;
        long BaseTime;
        long PauseTime;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.stopwatch);

            Output = (TextView) findViewById(R.id.time_out);
            Rec = (TextView) findViewById(R.id.record);
            BtnStart = (Button) findViewById(R.id.btn_start);
            BtnRec = (Button) findViewById(R.id.btn_rec);

            //화면전환 (알람)
            Button btnAlarm = (Button) findViewById(R.id.btnalram);
            btnAlarm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                }
            });
            //화면전환 (스톱워치)
            Button btnStopWatch = (Button) findViewById(R.id.btnstopwatch);
            btnStopWatch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(),stopwatch.class);
                    startActivity(intent);
                }
            });

            //화면전환 (타이머)
            Button btntimer = (Button) findViewById(R.id.btntimer);
            btntimer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(),timer.class);
                    startActivity(intent);
                }
            });

            //화면전환 (캘린더)
            Button btncalender = (Button) findViewById(R.id.btncalender);
            btncalender.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(),calender.class);
                    startActivity(intent);
                }
            });
        }


        public void myOnClick(View v){
            switch(v.getId()){
                case R.id.btn_start: //시작버튼을 클릭했을때 현재 상태값에 따라 다른 동작을 할수있게끔 구현.
                    switch(cur_Status){
                        case Init:
                            BaseTime = SystemClock.elapsedRealtime();
                            System.out.println(BaseTime);
                            //Timer이라는 핸들러를 빈 메세지를 보내서 호출
                            Timer.sendEmptyMessage(0);
                            BtnStart.setText("멈춤"); //버튼의 문자"시작"을 "멈춤"으로 변경
                            BtnRec.setEnabled(true); //기록버튼 활성
                            cur_Status = Run; //현재상태를 런상태로 변경
                            break;
                        case Run:
                            Timer.removeMessages(0); //핸들러 메세지 제거
                            PauseTime = SystemClock.elapsedRealtime();
                            BtnStart.setText("시작");
                            BtnRec.setText("리셋");
                            cur_Status = Pause;
                            break;
                        case Pause:
                            long now = SystemClock.elapsedRealtime();
                            Timer.sendEmptyMessage(0);
                            BaseTime += (now- PauseTime);
                            BtnStart.setText("멈춤");
                            BtnRec.setText("기록");
                            cur_Status = Run;
                            break;


                    }
                    break;
                case R.id.btn_rec:
                    switch(cur_Status){
                        case Run:

                            String str = Rec.getText().toString();
                            str +=  String.format("%d. %s\n",Count,getTimeOut());
                            Rec.setText(str);
                            Count++; //카운트 증가

                            break;
                        case Pause:
                            //핸들러를 멈춤
                            Timer.removeMessages(0);

                            BtnStart.setText("시작");
                            BtnRec.setText("기록");
                            Output.setText("00:00:00");

                            cur_Status = Init;
                            Count = 1;
                            Rec.setText("");
                            BtnRec.setEnabled(false);
                            break;


                    }
                    break;

            }
        }

        Handler Timer = new Handler(){
            public void handleMessage(Message msg){
                Output.setText(getTimeOut());

                //sendEmptyMessage 는 비어있는 메세지를 Handler 에게 전송
                Timer.sendEmptyMessage(0);
            }
        };

        //현재시간을 계속 구해서 출력하는 메소드
        String getTimeOut(){
            long now = SystemClock.elapsedRealtime(); //애플리케이션이 실행되고나서 실제로 경과된 시간
            long outTime = now - BaseTime;
            String easy_outTime = String.format("%02d:%02d:%02d", outTime/1000 / 60, (outTime/1000)%60,(outTime%1000)/10);
            return easy_outTime;

        }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
    }

    }
