import java.util.*;


class Calc{

	public int calculate(int a) {
		int sum=0;
		for(int i=1; i<a; i++) {
			if(i%2==1) {
				sum+=i;
			}
		}
		return sum;
	}
	
}
public class ex1 {
	
static void high(int[][] ary, int a, int b){
int top=0;
	for(int i=0; i<ary.length; i++) {
		for(int j=0; j<ary[i].length; j++) {
		if(ary[i][j]>top) {
			top=ary[i][j];
		}
		}
	}
	System.out.println(top);
}

	public static void main(String[] args) {

		Calc c = new Calc();
		Scanner sc = new Scanner(System.in);
		
		int[][] ary=new int[3][3];
		System.out.println("�����Է�");
		for(int i=0; i<ary.length; i++) {
			for(int j=0; j<ary[i].length; j++) {
			ary[i][j]=sc.nextInt();
			}
			
		}

		high(ary,3,3);
		
		while(true) {
			int n=sc.nextInt();
			if(n<5 || n>10) {
				System.out.println("�ٽ��Է�");
				continue;
			}
			System.out.println(c.calculate(n));
		}
		

	}

}
