import java.awt.Container;
import java.awt.FlowLayout;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;



public class ex3 extends JFrame{
	ex3(){
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		
		//��ü�迭
		ImageIcon ii[]= {
			new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/aaa.jpg"),
			 new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/abc.jpg"),
			new ImageIcon("C:\\Users\\chin4\\OneDrive\\Desktop/bbb.jpg")
		};
		
		//��ü�迭
		JLabel jj[]=new JLabel[3];
		
		for(int i=0; i<jj.length; i++) {
			jj[i]=new JLabel(ii[i]);
			c.add(jj[i]);
		}

		setSize(500,500);
		setVisible(true);
	}
	
	static int[] add(int a[],int b) {
		int sum=0;
		for(int i=0; i<a.length; i++) {
			sum+=a[i];
		}
		System.out.println(sum);
		return a;
		
	}


	public static void main(String[] args) throws IOException {
		FileOutputStream fo = new FileOutputStream("f1.txt");
		byte b[]={1,2,3,4,5};
		fo.write(b);   
		fo.close();
		
		FileInputStream fi = new FileInputStream("f1.txt");
		int n;
		while((n=fi.read())!=-1) {
			System.out.println(n);
		}
		fi.close();
		

		 int [] arr={1,2,3,4,5};

		 int [] r;

		 r=add(arr,5);
		 
		
		
		new ex3();
		

	}

}
