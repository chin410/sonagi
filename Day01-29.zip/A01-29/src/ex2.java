import java.util.*;

interface Cal{

	public int cal(int a, int b);
}

class Show implements Cal{
	int a;
	int b;
	
	public int cal(int a, int b) {
		int n=0;
		for(int i=a; i<b; i++) {
			n+=i;
		}
		return n;
	}
}

class Gen<T>{ //���ʸ� Ŭ������ ��Ʈ��,��Ʈ���̴� �� �ɼ� �ִ�
	T t;
	T d;
	Gen(T t,T d){
		this.t=t;
		this.d=d;
	}
	T one() {
		return t;
		
	}
	T two() {
		return d;
		
	}
	boolean three() {
		
		return t.equals(d);		
	}
}
public class ex2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);		
         Cal c= new Show();
         System.out.println("�Է�");
         int a=sc.nextInt();
         int b=sc.nextInt();
        System.out.println(c.cal(a,b));
        

Gen<String> g=new Gen<String>("seoul","busan");

System.out.println(g.one());   //seoul ���

System.out.println(g.two());   //busan ���

System.out.println(g.three());  //false ��� (�� ���ڿ� ��) 

	}

}
