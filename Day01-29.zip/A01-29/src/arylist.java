import java.util.ArrayList;

public class arylist {

	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<String>();
		a.add("�ο�");
		a.add("�̿�");
		a.add("�Ƹ�");
		
		for(int i=0; i<a.size(); i++) {
			System.out.println(a.get(i));
		}

	}

}
