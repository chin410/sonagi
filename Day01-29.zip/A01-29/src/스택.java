class St<T>{
	int n;
	Object [] obj;
	St(){
		n=0;
		obj=new Object[5];
	}
	void push(T t) {
		if(n==3)
			return;
		else
			obj[n]=t;
		n++;
	}
	
	   T pop() {
		if(n==0) {
			return null;
		}
		else {
			n--;
			return (T)obj[n];
		}
	}
} 
public class ���� {

	public static void main(String[] args) {
		St<String> str = new St<String>();
		str.push("�Ƹ�");
		str.push("�ƴ�");
		str.push("�ƶ�");
		
		for(int i=0; i<3; i++) {
			System.out.println(str.pop());
		}
		St<Integer> str1 = new St<Integer>();
		str1.push(1);
		str1.push(2);
		str1.push(3);
		
		for(int i=0; i<3; i++) {
			System.out.println(str1.pop());
		}

	}

}
