import java.util.Vector;
import java.util.Iterator;
import java.util.LinkedList;


public class ex4 {

	public static void main(String[] args) {
		/*Vector<Integer> v =new Vector<Integer>();
		
		v.add(1);
		v.add(2);
		v.add(3);
		
		Iterator<Integer> it = v.iterator();
		
		while(it.hasNext()) {
			int n=it.next();
			System.out.println(n);
		}*/
		
		LinkedList<String> li = new LinkedList<String>();
		
		li.add("one");
		li.add("two");
		li.add("three");
		
		Iterator<String> it = li.iterator();
		
		while(it.hasNext()) {
			String n=it.next();
			if(n.compareTo("two")==0) {
				it.remove();
			}
		}
		it=li.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		
	}

}
