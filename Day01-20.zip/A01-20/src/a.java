import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;

class Rectangle{
	int width,height;
	int area() {
		int n=width*height;
		return n;
	}
}

class Song{
	String song;
	Song(String song){
		this.song=song;
	}
	String getsong() {
		return song;
	}
}


public class a {

	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		
	    //1��
		double ary[]=new double[99];
		int n=0;
		double sum=0;
		while(true) {
			System.out.println("�Ǽ� �Է�");
			ary[n]=sc.nextDouble();
			if(ary[n]==-1) {
				break;
			}
			sum+=ary[n];
			n++;
		}
		System.out.printf("%.1f",sum/n);
		
		//2��
		FileWriter fw=new FileWriter("test01.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("Hi");
		bw.newLine();
		bw.write("���� �ڹٸ� �����ϰ� ���մϴ�.");
		bw.newLine();
		bw.write("������ �� ������ ����� �� �Դϴ�.");
		bw.newLine();
		bw.close();
		fw.close();

		
		//3��
		FileWriter fw1=new FileWriter("text02.txt");
		BufferedWriter bw1 = new BufferedWriter(fw1);
		String str;
		while(true) {
			System.out.println("�Է��� ����");
			str=sc.nextLine();
			if(str.equals("�׸�")) {
				break;
			}
			bw1.write(str);
			bw1.newLine();
		}
		bw1.close();
		fw1.close();
		
		//��ǲ��Ʈ�� ���� BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		
		
		
		//3-1
		FileReader fr = new FileReader("text02.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String str1=null;
		while((str1=br.readLine())!=null) {
			System.out.println(str1);
		}
		
		br.close();
		fr.close();
		
		//4��
	     Rectangle rec = new Rectangle();
	     rec.width=5;
	     rec.height=6;
	     System.out.println("�簢�� ���� "+ rec.area( ));
	     
	     //5��
	     Song s1 = new Song("On");
	     Song s2 = new Song("00:00");
	     System.out.println("�����ϴ� �뷡 " + s1.getsong());
	     System.out.println("�� �뷡 " + s2.getsong());


		
		
		
	}



}
