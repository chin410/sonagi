import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

    
public class Day01_20 {

	public static void main(String[] args) throws IOException {
		
		//������Ʈ �ƿ�ǲ ��Ʈ��
		ObjectOutputStream os=null;
		
		try {
			os=new ObjectOutputStream(new FileOutputStream("ob.txt"));
			
			Stu s = new Stu();
			s.setName("�ο�");
			s.setAge(24);
			s.setId("43");
			
			os.writeObject(s);
			
			
		}catch(Exception e) {}
		os.close();
		
		FileInputStream dd = new FileInputStream("ob.txt");
		ObjectInputStream in = new ObjectInputStream(dd);
		
		try {
		Stu s=(Stu)in.readObject();
		System.out.println(s.getName());
		System.out.println(s.getId());
		System.out.println(s.getAge());
		}catch(Exception e) {}
		in.close();
		
	


	}

}
