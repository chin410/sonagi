class Circle{
	private int a;
	Circle(int a){
		this.a=a;
	}
	void get() {
		System.out.println(a);
	}
}

class NCircle extends Circle{
	
	private String b;
	NCircle(int a,String b){
		super(a);
		this.b=b;
	}
	void show() {
		get();
		System.out.println(b);
	}
}
public class b {

	public static void main(String[] args) {
		NCircle n = new NCircle(10,"red");
		n.show();

	}

}
