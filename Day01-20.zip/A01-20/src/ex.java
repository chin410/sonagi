
class Score{
	void show(int a[][]){
		int sum=0;
		int cnt=0;
		for(int i=0; i<a.length; i++) {
			for(int j=0; j<a[i].length; j++) {
				sum+=a[i][j];
				cnt++;
			}
		}
		double avg=(double)sum/cnt;
		System.out.printf("�����:%.1f",avg);
	}
}
public class ex {

	public static void main(String[] args) {
		
		int [][] grade= {{90,100,80},
	            {70,95,87},
	            {80,90,70},
	            {90,100,100}};
		
		Score s=new Score();
		s.show(grade);

	}

}
