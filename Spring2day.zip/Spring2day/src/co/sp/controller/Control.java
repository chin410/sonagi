package co.sp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Control {
	                //URL 주소
	@RequestMapping(value = "/",method =RequestMethod.GET )
	public String root() {
		return "start5"; //servletApp으로 보낼 리턴 값
	}
	
	@RequestMapping(value = "two/java",method = RequestMethod.GET)
	public String query(HttpServletRequest req) {
		String da1=req.getParameter("da1");
		String da2=req.getParameter("da2");
		String da3[]=req.getParameterValues("da3");
		
		req.setAttribute("da1", da1);
		req.setAttribute("da2", da2);
		req.setAttribute("d3", da3[0]);
		req.setAttribute("da3", da3[1]);
		return "two/java";
	}
	
	@RequestMapping(value = "two/java2",method = RequestMethod.POST)
	public String query2(HttpServletRequest req) {
		String da1=req.getParameter("da1");
		String da2=req.getParameter("da2");
		String da3[]=req.getParameterValues("da3");
		
		req.setAttribute("da1", da1);
		req.setAttribute("da2", da2);
		for(int i=0; i<da3.length; i++) {
			System.out.println(da3[i]);
		}
			
		return "two/java2";
	}
	
	@GetMapping(value = "two/java3/{d1}/{d2}/{d3}")
	public String query3(@PathVariable int d1,@PathVariable int d2,@PathVariable int d3,HttpServletRequest req) {
		req.setAttribute("d1", d1);
		req.setAttribute("d2", d2);
		req.setAttribute("d3", d3);
		return "two/java3";
	}
	
	@GetMapping(value = "two/java4")
	public String query4(@RequestParam int da1,@RequestParam int da2,@RequestParam int da3[],HttpServletRequest req) {
		req.setAttribute("da1",da1);
		req.setAttribute("da2",da2);
		
		for(int d:da3) {
			System.out.println(d);
		}
		
		return "two/java4";
		
	}
	
	@GetMapping("two/java5")
	public String query5(@RequestParam(value = "da1") int va1,
			             @RequestParam(value = "da2") int va2,
			             @RequestParam(value = "da3")int va3[]) {
		System.out.println(va1);
		System.out.println(va2);
		for(int v : va3) {
			System.out.println(v);
		}
		return "two/java5";
	}
	
	@GetMapping(value = "two/java6")
	public String query6(@RequestParam int da1,
			             @RequestParam(required = false) String da2,
			             @RequestParam(defaultValue = "0") int da) {
		
		System.out.println(da1);
		System.out.println(da2);
		System.out.println(da);
		return "two/java6";
	}
	
	
}
